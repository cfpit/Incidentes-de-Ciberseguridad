package objetos;

public class App {
    public static void main(String[] args) throws Exception {
       //creo 2 objetos de la clase Auto
        Auto a = new Auto();        
        Auto b = new Auto("Ford", 25);

        //comportamiento
        b.acelerar();//25 --> 35
        b.acelerar(30);//35 --> 65

        //ver el estado de los objetos
        System.out.println(a.toString());
        System.out.println("-------------------");
        System.out.println(b);
       
       
    }
}
