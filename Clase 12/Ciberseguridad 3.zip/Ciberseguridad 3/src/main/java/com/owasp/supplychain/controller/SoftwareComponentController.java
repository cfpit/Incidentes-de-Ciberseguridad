package com.owasp.supplychain.controller;

import com.owasp.supplychain.dto.ComponentRequest;
import com.owasp.supplychain.dto.ValidationResponse;
import com.owasp.supplychain.model.SoftwareComponent;
import com.owasp.supplychain.service.SoftwareComponentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/components")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class SoftwareComponentController {

    private final SoftwareComponentService service;

    /**
     * ENDPOINT VULNERABLE: Demonstrates OWASP A03:2025
     * Ingesta componentes sin validar hash SHA-256 ni dominio de origen.
     */
    @PostMapping("/vulnerable")
    public ResponseEntity<ValidationResponse> registerVulnerable(@RequestBody ComponentRequest request) {
        ValidationResponse response = service.processVulnerableIngestion(request);
        return ResponseEntity.ok(response);
    }

    /**
     * ENDPOINT MITIGADO: Demuestra la solución a OWASP A03:2025
     * Valida lista blanca de proveedores y coincidencia estricta del SHA-256.
     */
    @PostMapping("/mitigated")
    public ResponseEntity<ValidationResponse> registerMitigated(@RequestBody ComponentRequest request) {
        ValidationResponse response = service.processMitigatedIngestion(request);
        if (!response.isSuccess()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
        return ResponseEntity.ok(response);
    }

    /**
     * LISTAR COMPONENTES REGISTRADOS EN MYSQL
     */
    @GetMapping
    public ResponseEntity<List<SoftwareComponent>> getAllComponents() {
        return ResponseEntity.ok(service.getAllComponents());
    }

    /**
     * LIMPIAR BASE DE DATOS
     */
    @DeleteMapping
    public ResponseEntity<String> clearDatabase() {
        service.clearAll();
        return ResponseEntity.ok("Base de datos limpiada correctamente.");
    }
}
