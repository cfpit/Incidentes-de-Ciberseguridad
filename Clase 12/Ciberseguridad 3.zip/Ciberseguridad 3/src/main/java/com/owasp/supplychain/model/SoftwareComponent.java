package com.owasp.supplychain.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entidad JPA que representa un componente o dependencia de software
 * evaluado o registrado en la cadena de suministro.
 * <p>
 * Modela el estado de seguridad, origen, integridad criptográfica (checksums)
 * y modo de ingesta (vulnerable vs. mitigado) dentro del contexto de OWASP A03:2025.
 */
@Entity
@Table(name = "software_components")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SoftwareComponent {

    /**
     * Identificador único del registro en base de datos.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Nombre de la librería, paquete o componente de software (ej. 'express', 'spring-core').
     */
    @Column(nullable = false)
    private String name;

    /**
     * Versión del componente (ej. '1.0.0', '2.5.4').
     */
    @Column(nullable = false)
    private String version;

    /**
     * URL del repositorio o registro de origen de donde proviene la dependencia.
     */
    @Column(nullable = false, length = 500)
    private String repositoryUrl;

    /**
     * Checksum SHA-256 declarado por el proveedor o en la solicitud de ingesta.
     */
    @Column(length = 64)
    private String declaredChecksum;

    /**
     * Checksum SHA-256 calculado o validado a partir de fuentes de confianza.
     */
    @Column(length = 64)
    private String computedChecksum;

    /**
     * Indica si el dominio o proveedor del componente pertenece a la lista blanca de confianza.
     */
    private Boolean trustedSupplier;

    /**
     * Estado del componente tras pasar o fallar las políticas de seguridad (INSTALLED, REJECTED_*).
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ComponentStatus status;

    /**
     * Modo en que fue procesado el componente: 'VULNERABLE_INGESTION' o 'MITIGATED_INGESTION'.
     */
    @Column(nullable = false)
    private String installationMode; // VULNERABLE_INGESTION or MITIGATED_INGESTION

    /**
     * Detalles y justificación del resultado del proceso de validación.
     */
    @Column(length = 1000)
    private String validationDetails;

    /**
     * Fecha y hora en la que se registró el componente en el sistema.
     */
    private LocalDateTime createdAt;

    /**
     * Asigna automáticamente la fecha y hora de creación antes de persistir en base de datos.
     */
    @PrePersist
    public void prePersist() {
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
    }
}
