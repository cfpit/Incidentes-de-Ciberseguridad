package com.owasp.supplychain.dto;

import com.owasp.supplychain.model.SoftwareComponent;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ValidationResponse {

    private boolean success;
    private String mode; // VULNERABLE or MITIGATED
    private String message;
    private String vulnerabilityExplanation;
    private SoftwareComponent component;
    private LocalDateTime timestamp;
}
