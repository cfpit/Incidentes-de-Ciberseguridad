package com.owasp.supplychain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ComponentRequest {

    private String name;
    private String version;
    private String repositoryUrl;
    private String checksumSha256;
    private String expectedSha256; // Hash esperado oficial en la lockfile
}
