package com.owasp.supplychain.repository;

import com.owasp.supplychain.model.SoftwareComponent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SoftwareComponentRepository extends JpaRepository<SoftwareComponent, Long> {

    /**
     * Recupera la lista de componentes filtrados por el modo de instalación o ingesta
     * ('VULNERABLE_INGESTION' o 'MITIGATED_INGESTION'), ordenados cronológicamente
     * desde el más reciente al más antiguo (fecha de creación descendente).
     *
     * @param installationMode Modo de ingesta utilizado para registrar el componente.
     * @return Lista de componentes que coinciden con el modo especificado.
     */
    List<SoftwareComponent> findByInstallationModeOrderByCreatedAtDesc(String installationMode);

    /**
     * Recupera todos los componentes de software registrados en la base de datos,
     * ordenados cronológicamente desde el más reciente al más antiguo.
     * Sirve para mostrar el historial completo de auditoría y análisis en la interfaz.
     *
     * @return Lista de todos los componentes registrados ordenados por fecha descendente.
     */
    List<SoftwareComponent> findAllByOrderByCreatedAtDesc();
}
