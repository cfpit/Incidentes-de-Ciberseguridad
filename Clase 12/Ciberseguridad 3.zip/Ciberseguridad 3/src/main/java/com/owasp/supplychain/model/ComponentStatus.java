package com.owasp.supplychain.model;

public enum ComponentStatus {
    INSTALLED,
    REJECTED_UNTRUSTED_SUPPLIER,
    REJECTED_CHECKSUM_MISMATCH,
    REJECTED_MALICIOUS_CONTAINER
}

/*
 * DESCRIPCIÓN DE LA ENUMERACIÓN:
 * Representa los diferentes estados de validación e ingesta de un componente de software 
 * dentro de los controles de seguridad de la cadena de suministro (OWASP A03:2025):
 * 
 * - INSTALLED: El componente fue verificado e instalado exitosamente (o aceptado en modo vulnerable).
 * - REJECTED_UNTRUSTED_SUPPLIER: Rechazado porque el proveedor o repositorio no está en la lista blanca de dominios confiables.
 * - REJECTED_CHECKSUM_MISMATCH: Rechazado por discrepancia en el hash SHA-256 (posible manipulación o envenenamiento).
 * - REJECTED_MALICIOUS_CONTAINER: Rechazado por detección de código malicioso o vulnerabilidades críticas en el artefacto/contenedor.
 */
