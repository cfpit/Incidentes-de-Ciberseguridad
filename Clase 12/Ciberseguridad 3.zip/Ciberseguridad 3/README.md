# 🛡️ Laboratorio Spring Boot: OWASP A03:2025 - Fallos en la Cadena de Suministro de Software

Este proyecto es una aplicación **Spring Boot 3** interactiva desarrollada con **Java 17+**, **Spring Data JPA**, **Hibernate** y **MySQL**. Su objetivo es explicar y demostrar de forma sencilla la vulnerabilidad de la lista OWASP Top 10 **A03:2025 — Fallos en la Cadena de Suministro de Software (Software Supply Chain Failures)**, comparando el comportamiento de un endpoint **Vulnerable** frente a un endpoint **Mitigado (Seguro)**.

---

## 💡 1. Explicación Sencilla de OWASP A03:2025

### ¿Qué es un fallo en la cadena de suministro de software?

La cadena de suministro de software está formada por todas las librerías, paquetes y componentes de terceros que importamos en nuestras aplicaciones (por ejemplo, dependencias Maven, NPM, PyPI o scripts ejecutados remotamente).

Un **fallo en la cadena de suministro** ocurre cuando la aplicación o el pipeline de integración (CI/CD):

1. **Descarga e instala componentes desde fuentes no verificadas** (sitios web o repositorios no confiables).
2. **No comprueba la integridad criptográfica (Hash SHA-256)** del paquete recibido comparándolo contra un registro de firmas o archivo *lockfile*.
3. **Es vulnerable a ataques de *Typosquatting* o sustitución de artefactos**, permitiendo que un atacante inyecte un paquete manipulado (troyano) con el mismo nombre o versión.

---

## 🏗️ 2. Estructura del Proyecto y Capas

La solución sigue la arquitectura limpia de Spring Boot:

- **`model` (`SoftwareComponent.java`)**: Entidad JPA mapeada a MySQL (`software_components`) con campos como `name`, `version`, `repositoryUrl`, `checksumSha256`, `status` y `installationMode`.
- **`repository` (`SoftwareComponentRepository.java`)**: Interfaz que extiende `JpaRepository` para operaciones CRUD en MySQL.
- **`service` (`SoftwareComponentService.java`)**: Contiene la lógica de negocio:
  - **Proceso Vulnerable**: Acepta cualquier componente sin validar su hash ni el dominio de origen.
  - **Proceso Mitigado**: Aplica lista blanca de dominios confiables y verifica la coincidencia estricta del checksum SHA-256 contra el *lockfile* / SBOM.
- **`controller` (`SoftwareComponentController.java`)**: Expone la API REST en `/api/components`.
- **`static/index.html`**: Interfaz gráfica web moderna en HTML/CSS/JS para probar visualmente la vulnerabilidad.

### Dependencias en el `pom.xml`

1. `spring-boot-starter-web` (Spring Web REST)
2. `spring-boot-devtools` (DevTools para Hot Reloading)
3. `lombok` (Anotaciones `@Data`, `@Builder`, etc.)
4. `spring-boot-starter-data-jpa` (JPA / Hibernate ORM)
5. `mysql-connector-j` (Driver de MySQL)

---

## ⚙️ 3. Configuración y Ejecución

### Opción A: Ejecutar con MySQL (Recomendado)

1. Inicia tu servidor MySQL.
2. Crea la base de datos (Spring Boot la creará automáticamente si está configurado `createDatabaseIfNotExist=true`):
   ```sql
   CREATE DATABASE IF NOT EXISTS supplychain_db;
   ```
3. Verifica usuario y clave en `src/main/resources/application.properties`:
   ```properties
   spring.datasource.url=jdbc:mysql://localhost:3306/supplychain_db?createDatabaseIfNotExist=true
   spring.datasource.username=root
   spring.datasource.password=root
   ```

### Opción B: Probar inmediatamente con H2 (Base de datos en memoria)

Si no tienes MySQL instalado, abre `src/main/resources/application.properties` y desmarca las líneas del perfil **H2 Database**.

### Compilar y Arrancar la App

En la consola del proyecto, ejecuta:

```bash
mvn spring-boot:run
```

O compila e inicia la clase `SupplyChainApplication.java` desde tu IDE (IntelliJ, Eclipse o VS Code).

---

## 🌐 4. Interfaz Web Interactiva

Una vez arrancada la aplicación, abre tu navegador web en:
👉 **[http://localhost:8080](http://localhost:8080)**

Podrás:

- Probar con botones de escenarios predefinidos (*Librería Legítima*, *Repositorio Dudoso*, *Hash Troyanizado*).
- Ejecutar la ingesta por el **Endpoint Vulnerable** o el **Endpoint Mitigado**.
- Ver los registros guardados en tiempo real dentro de MySQL.

---

## 🚀 5. Rutas y Pruebas para Bruno o Postman

El proyecto incluye dos archivos listos para importar directamente en tu cliente API:

- 📄 `bruno-collection.json` (Colección para **Bruno**)
- 📄 `postman_collection.json` (Colección para **Postman**)

### Resumen de Endpoints:

| Método    | Endpoint                       | Descripción                                                                                           |
| :--------- | :----------------------------- | :----------------------------------------------------------------------------------------------------- |
| `POST`   | `/api/components/vulnerable` | **[VULNERABLE]** Registra el componente sin verificar el hash ni la reputación del repositorio. |
| `POST`   | `/api/components/mitigated`  | **[MITIGADO]** Aplica lista blanca de dominios y validación de hash SHA-256.                    |
| `GET`    | `/api/components`            | Lista todos los componentes auditados y su estado en MySQL.                                            |
| `DELETE` | `/api/components`            | Limpia la tabla de la base de datos.                                                                   |

---

### Ejemplos de Peticiones HTTP

#### 🔴 1. Endpoint Vulnerable (Permite Paquetes Maliciosos)

- **POST** `http://localhost:8080/api/components/vulnerable`
- **Headers**: `Content-Type: application/json`
- **Body JSON**:

```json
{
  "name": "untrusted-logger-patch",
  "version": "1.0.0-hacked",
  "repositoryUrl": "http://malicious-cdn.untrusted-mirror.com/downloads",
  "checksumSha256": "8888888888888888888888888888888888888888888888888888888888888888",
  "expectedSha256": "8888888888888888888888888888888888888888888888888888888888888888"
}
```

*Resultado*: Responde `200 OK` e instala el componente, ignorando que proviene de un origen malicioso sin verificar (`VULNERABLE_INGESTION`).

---

#### 🛡️ 2. Endpoint Mitigado — Prueba 1: Rechazo por Repositorio No Autorizado

- **POST** `http://localhost:8080/api/components/mitigated`
- **Headers**: `Content-Type: application/json`
- **Body JSON**:

```json
{
  "name": "untrusted-logger-patch",
  "version": "1.0.0-hacked",
  "repositoryUrl": "http://malicious-cdn.untrusted-mirror.com/downloads",
  "checksumSha256": "8888888888888888888888888888888888888888888888888888888888888888",
  "expectedSha256": "8888888888888888888888888888888888888888888888888888888888888888"
}
```

*Resultado*: Responde `400 Bad Request`. Bloquea la instalación con el mensaje: `REJECTED_UNTRUSTED_SUPPLIER` porque el dominio no está en la lista blanca de proveedores autorizados.

---

#### 🛡️ 3. Endpoint Mitigado — Prueba 2: Rechazo por Alteración de Integridad (SHA-256 Mismatch)

- **POST** `http://localhost:8080/api/components/mitigated`
- **Headers**: `Content-Type: application/json`
- **Body JSON**:

```json
{
  "name": "log4j-core",
  "version": "2.14.1",
  "repositoryUrl": "https://repo.maven.apache.org/maven2/org/apache/logging/log4j",
  "checksumSha256": "HASH_ALTERADO_TROYANIZADO_9999999999999999999999999999999999",
  "expectedSha256": "HASH_OFICIAL_DEL_LOCKFILE_1111111111111111111111111111111111"
}
```

*Resultado*: Responde `400 Bad Request`. Bloquea la instalación con el mensaje: `REJECTED_CHECKSUM_MISMATCH` indicando que el hash del paquete fue alterado en tránsito.

---

#### 🛡️ 4. Endpoint Mitigado — Prueba 3: Ingesta Exitosa de Librería Verificada

- **POST** `http://localhost:8080/api/components/mitigated`
- **Headers**: `Content-Type: application/json`
- **Body JSON**:

```json
{
  "name": "jackson-databind",
  "version": "2.15.2",
  "repositoryUrl": "https://repo.maven.apache.org/maven2/com/fasterxml/jackson/core",
  "checksumSha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "expectedSha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
}
```

*Resultado*: Responde `200 OK`. Aprueba la instalación con estado `INSTALLED` y `trustedSupplier = true`.

---

#### 📋 5. Consultar Histórico Persistido en MySQL

- **GET** `http://localhost:8080/api/components`

---

## 💻 Comandos `curl` para Terminal

```bash
# 1. Probar Endpoint Vulnerable
curl -X POST http://localhost:8080/api/components/vulnerable \
  -H "Content-Type: application/json" \
  -d '{"name":"hacked-lib","version":"1.0","repositoryUrl":"http://malicious.com","checksumSha256":"1234"}'

# 2. Probar Endpoint Mitigado (Seguro)
curl -X POST http://localhost:8080/api/components/mitigated \
  -H "Content-Type: application/json" \
  -d '{"name":"jackson-databind","version":"2.15.2","repositoryUrl":"https://repo.maven.apache.org/maven2/com/fasterxml/jackson/core","checksumSha256":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","expectedSha256":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"}'

# 3. Listar registros en MySQL
curl -X GET http://localhost:8080/api/components
```

---

## 📝 Conclusión y Buenas Prácticas OWASP A03:2025

1. **Uso de Archivos Lockfile (`pom.xml` / `package-lock.json` / `Cargo.lock`)**: Bloquear los hashes exactos (SHA-256 / SHA-512) de cada artefacto descargado.
2. **Generación y Auditoría de SBOM (Software Bill of Materials)**: Mantener un inventario automático de componentes.
3. **Lista blanca de repositorios empresariales**: Desactivar la descarga automática desde URLs HTTP públicas no confiables.
4. **Verificación Criptográfica de Firmas**: Exigir firmas GPG/Cosign para artefactos de software en los pipelines CI/CD.
