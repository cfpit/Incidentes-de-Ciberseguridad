package com.example.demo.service;

import com.example.demo.entity.Invoice;
import com.example.demo.repository.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class InvoiceService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    // Retorno directo sin validación de usuario (para demostrar la vulnerabilidad IDOR)
    public Invoice getInvoiceByIdUnsafe(Long id) {
        return invoiceRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Factura no encontrada"));
    }

    // Validación de propiedad en la capa de negocio (Mitigación)
    public Invoice getInvoiceByIdSecure(Long id, String currentUser) {
        Invoice invoice = getInvoiceByIdUnsafe(id);

        // Control de acceso explícito: verifica que el ownerUsername coincida con el usuario autenticado
        if (!invoice.getOwnerUsername().equalsIgnoreCase(currentUser)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Acceso denegado: no eres el propietario de esta factura");
        }

        return invoice;
    }
}
