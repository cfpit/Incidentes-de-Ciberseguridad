package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String clientName;     // Destinatario de la factura (ej: "Coca-Cola Argentina")
    private Double amount;         // Monto de la factura
    private String ownerUsername;  // Dueño legítimo en el sistema (ej: "eri_dev")

    public Invoice() {}

    public Invoice(String clientName, Double amount, String ownerUsername) {
        this.clientName = clientName;
        this.amount = amount;
        this.ownerUsername = ownerUsername;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getClientName() { return clientName; }
    public void setClientName(String clientName) { this.clientName = clientName; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public String getOwnerUsername() { return ownerUsername; }
    public void setOwnerUsername(String ownerUsername) { this.ownerUsername = ownerUsername; }
}
