package ar.edu.centro8.ic.dinamico.controller;
import ar.edu.centro8.ic.dinamico.model.Cliente;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;

@RestController
public class SaludoController {

    //endpoint
    @GetMapping("/saludo")
    public String saludo() {
        return "¡Hola, mundo!";
    }

    //uso de PathVariable
    @GetMapping("/saludo/{nombre}") 
    public String saludoNombre(@PathVariable String nombre) {
        return "¡Hola, " + nombre + "!";
    }

    //uso de RequestParam
    @GetMapping("/saludo2")
    public String saludoNombre2(@RequestParam String nombre) {
        return "¡Hola, " + nombre + "!";
    }

    //postmapping
    @PostMapping("/saludo3")
    public String saludoNombre3(@RequestBody String nombre) {
        return "¡Hola, " + nombre + "!";
    }
    
    @PostMapping("/saludo4")
    public String saludoNombre4(@RequestBody Cliente c) {
        return "¡Hola, " + c.getNombre() + "!, tenes " + c.getEdad() + " años.";
    }


}

