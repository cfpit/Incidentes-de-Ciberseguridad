package colecciones;

import java.util.HashSet;
import java.util.Iterator;

public class App {
    public static void main(String[] args) throws Exception {
        // creo un ArrayList de Strings
        // ArrayList<String> lista = new ArrayList<String>();// coleccion tipada
        HashSet<String> lista = new HashSet<String>();// coleccion tipada

        // agrego 4 strings a la lista
        lista.add("Hola");
        lista.add("Mundo");
        lista.add("Como");
        lista.add("Estas");
        lista.add("Estas");//el HashSet evita objetos duplicados

        // recorro la lista con un for each
        for (String elemento : lista) {
            System.out.println(elemento);
        }

        System.out.println("Tamaño de la lista: " + lista.size());//4

        System.out.println("-----------------------------------");

        // elimino el elemento "Como" de la lista
        lista.remove("Como");

        // recorro la lista nuevamente con un patron de diseño Iterator
        Iterator<String> it = lista.iterator();

        while (it.hasNext()) {
            String elemento = it.next();
            System.out.println(elemento);
        }

    }
}
