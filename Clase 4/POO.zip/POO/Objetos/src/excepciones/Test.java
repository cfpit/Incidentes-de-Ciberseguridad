package excepciones;

public class Test {
    public static void main(String[] args) {
        System.out.println("Inicio del programa");
        
        try {
            int resultado = 10/0;//se lanza la excepción ArithmeticException
            System.out.println("Resultado: " + resultado);
            String palabra = null;
            palabra.length();//se lanza la excepción NullPointerException
        } catch (ArithmeticException e) {
            e.printStackTrace();
            System.out.println("Error: División por cero");
            System.out.println(e.getMessage());
        } catch (NullPointerException e) {
            e.printStackTrace();
            System.out.println("Error: Referencia nula");
            System.out.println(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error: Excepción genérica");
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Bloque finally ejecutado");
        }
        

        System.out.println("Fin del programa");
    }
}
