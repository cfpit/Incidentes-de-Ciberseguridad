package objetos;

public class Auto {
    // atributos
    public String marca;
    private int velocidad;

    // constructor vacio
    public Auto() {
    }

    // constructor parametrizado
    public Auto(String marca, int velocidad) {
        this.marca = marca;
        this.setVelocidad(velocidad);
    }

    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        //regla de negocio
        if(velocidad >= 0 && velocidad <= 130){
            this.velocidad = velocidad;
        }else{
            System.out.println("Velocidad fuera de rango");        
        }
    }

    // metodos
    public void acelerar() {
        this.setVelocidad(this.velocidad + 10);
    }

    

    // sobrecargo el metodo acelerar con 1 parametro
    public void acelerar(int km) {
        this.setVelocidad(this.velocidad + km);
    }

    public int sumar(int n1, int n2) {
        return n1 + n2;
    }

    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", velocidad=" + velocidad + "]";
    }

}
