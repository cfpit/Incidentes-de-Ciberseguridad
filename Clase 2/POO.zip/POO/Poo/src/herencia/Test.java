package herencia;

public class Test {
    public static void main(String[] args) {
        //creo un auto y un ato de carrera
        Auto auto = new Auto("Toyota", 100);
        AutoCarrera autoCarrera = new AutoCarrera("Ferrari", 200, "Aleron de fibra de carbono");

        //acelero ambos autos
        auto.acelerar();
        autoCarrera.acelerar();

        //muestro los datos de los autos
        System.out.println(auto);
        System.out.println(autoCarrera);
    }
}