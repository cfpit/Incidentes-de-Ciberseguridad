package herencia;

public class AutoCarrera extends Auto {
    private String tipoAleron;

    //constructor vacio
    public AutoCarrera() {}
    
    public AutoCarrera(String marca, int velocidad, String tipoAleron) {
        super(marca, velocidad);
        this.tipoAleron = tipoAleron;
    }

    //getter y setter
    public String getTipoAleron() {
        return tipoAleron;
    }

    public void setTipoAleron(String tipoAleron) {
        this.tipoAleron = tipoAleron;
    }

    //metodos
    //aplico polimorfismo, sobreescribiendo el cuerpo del metodo acelerar de la clase Auto
    @Override
    public void acelerar() {
        this.velocidad += 50;
    }


    //toString
    @Override
    public String toString() {
        return super.toString() + ", tipoAleron=" + tipoAleron + "]";
    }

    

}
