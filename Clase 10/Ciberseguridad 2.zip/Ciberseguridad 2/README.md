# 🛡️ Demostración OWASP A02:2025 – Configuración de Seguridad Incorrecta

Este proyecto es una aplicación web didáctica desarrollada en **Spring Boot 3** con conexión a **MySQL** y un frontend interactivo, diseñada para analizar y entender de manera sencilla la vulnerabilidad **OWASP A02:2025 - Security Misconfiguration (Configuración de Seguridad Incorrecta)** y cómo solucionarla.

---

## 💡 ¿Cómo funciona la vulnerabilidad y su solución?

La **Configuración de Seguridad Incorrecta** ocurre cuando la aplicación o la API expone información técnica o datos confidenciales debido a malas prácticas o falta de sanitización:

1. **❌ El Problema (Vulnerable)**:
   - **Exposición excesiva de datos**: El endpoint `/api/vulnerable/users/{id}` devuelve la entidad completa de la base de datos (`User`), enviando al cliente el hash de la contraseña (`password`) y la clave secreta de API (`secretApiKey`).
   - **Fuga de trazas/Stack traces**: Si buscas un usuario que no existe (ej. ID `999`), la aplicación expone la traza interna de errores de Java/Hibernate debido a la configuración `server.error.include-stacktrace=always`.

2. **✅ La Solución (Mitigado)**:
   - **Sanitización con DTO**: El endpoint `/api/mitigated/users/{id}` mapea la entidad a un objeto de transferencia `UserDTO`, enviando únicamente los campos seguros (`id`, `username`, `email`, `role`).
   - **Manejo limpio de excepciones**: Se usa `GlobalExceptionHandler` (`@RestControllerAdvice`) para responder con un mensaje JSON genérico (HTTP 404) sin revelar trazas ni estructura interna del servidor.

---

## 🛠️ Requisitos Previos

- **Java 17** o superior instalados.
- **Maven** instalado (o mediante el plugin de tu IDE).
- **MySQL** en ejecución con un usuario y contraseña configurados.

---

## 🚀 Pasos para Ejecutar la Aplicación

1. **Configurar la base de datos MySQL**:
   - Abre `src/main/resources/application.properties` y verifica la conexión a tu servidor MySQL:
     ```properties
     spring.datasource.url=jdbc:mysql://localhost:3306/ciberseguridad_db?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
     spring.datasource.username=root
     spring.datasource.password=root
     ```

2. **Iniciar la aplicación Spring Boot**:
   Ejecuta el siguiente comando en la terminal desde la raíz del proyecto:
   ```bash
   mvn spring-boot:run
   ```

3. **Abrir en el Navegador**:
   Ingresa a: **[http://localhost:8080](http://localhost:8080)**

---

## 🧪 Pruebas Interactivas desde la Interfaz Web

Al ingresar a `http://localhost:8080`, verás un panel gráfico donde puedes:
- **Seleccionar usuarios de prueba**: ID `1` (Admin), ID `2` (Dev) o ID `999` (Inexistente).
- **Probar el Endpoint Vulnerable**: Verás resaltados en color rojo los datos sensibles expuestos (`password` y `secretApiKey`) o la fuga de traza de pila al buscar el ID `999`.
- **Probar el Endpoint Mitigado**: Verás la respuesta limpia con `UserDTO` y respuestas de error HTTP 404 estandarizadas en verde.

---

## 📌 Endpoints Disponibles

| Método | Endpoint | Tipo | Descripción |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/vulnerable/users/{id}` | ❌ Vulnerable | Retorna la entidad `User` completa (expone contraseñas y llaves secretas). |
| `GET` | `/api/mitigated/users/{id}` | ✅ Mitigado | Retorna `UserDTO` sanitizado (solo datos públicos) y maneja errores de forma segura. |
