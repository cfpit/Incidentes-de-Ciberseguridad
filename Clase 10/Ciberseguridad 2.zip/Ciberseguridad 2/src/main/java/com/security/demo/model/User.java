package com.security.demo.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String role;

    // ⚠️ ATENCIÓN: Campo sensible (Hash de contraseña). 
    // Si se expone en la API directamente por mala configuración, viola OWASP A02:2025.
    @Column(nullable = false)
    private String password;

    // ⚠️ ATENCIÓN: Campo altamente confidencial (Llave de API secreta del servidor).
    //podría usarse para:
    // Autenticar requests a APIs externas (Stripe, SendGrid, etc.)
    // Firmar tokens JWT
    // Acceder a recursos restringidos
    // Encriptación simétrica de datos personales
    @Column(name = "secret_api_key", nullable = false)
    private String secretApiKey;
}


/*
    @Builder es una anotación de Lombok que implementa el patrón de diseño Builder automáticamente. Te permite crear objetos de forma más legible y flexible.

¿Qué hace?
Genera automáticamente un builder para construir instancias de la clase de manera fluida, sin necesidad de constructores con múltiples parámetros.

Ejemplo con tu clase User:
Sin @Builder (forma tradicional):
User user = new User(null, "john", "john@email.com", "ADMIN", "hashed123", "secret-key");
// ❌ Difícil de leer, hay que recordar el orden de los parámetros

Con @Builder (forma recomendada):
User user = User.builder()
        .username("john")
        .email("john@email.com")
        .role("ADMIN")
        .password("hashed123")
        .secretApiKey("secret-key")
        .build();
// ✅ Más legible, no hay que recordar el orden de los parámetros

Ventajas:
Legibilidad: Se ve claramente qué valor corresponde a qué campo
Flexibilidad: Puedes omitir campos opcionales
Inmutabilidad: Puedes combinar con @Value para objetos inmutables
Mantenibilidad: Si añades campos, el builder se actualiza automáticamente
Lo que Lombok genera por ti:
Una clase interna UserBuilder
Métodos username(), email(), role(), etc. en el builder
Un método build() que crea la instancia final
Un método estático builder() para iniciar la construcción
*/
