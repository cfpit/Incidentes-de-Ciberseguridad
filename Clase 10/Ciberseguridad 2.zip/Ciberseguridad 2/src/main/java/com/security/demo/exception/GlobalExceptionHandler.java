package com.security.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // Excepción para manejar recursos no encontrados de manera mitigada y limpia
    public static class UserNotFoundException extends RuntimeException {
        public UserNotFoundException(String message) {
            super(message);
        }
    }

    // ✅ MITIGACIÓN: En lugar de retornar un HTML con stacktrace completo de Hibernate/MySQL, 
    // retornamos una respuesta JSON estándar y sanitizada.
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleUserNotFound(UserNotFoundException ex) {
        Map<String, Object> body = new HashMap<>();
        body.put("timestamp", LocalDateTime.now().toString());
        body.put("status", HttpStatus.NOT_FOUND.value());
        body.put("error", "Recurso no encontrado");
        body.put("message", ex.getMessage());
        body.put("mitigationNote", "✅ Trazas de depuración del servidor ocultadas correctamente (OWASP A02 Mitigado).");
        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
    }
}
