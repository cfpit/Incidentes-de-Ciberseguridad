package com.security.demo;

import com.security.demo.model.User;
import com.security.demo.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SecurityMisconfigApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecurityMisconfigApplication.class, args);
    }

    // Carga de datos iniciales en la base de datos MySQL en caso de que no existan
    @Bean
    public CommandLineRunner initData(UserRepository userRepository) {
        return args -> {
            if (userRepository.count() == 0) {
                User admin = User.builder()
                        .username("admin_ciberseguridad")
                        .email("admin@empresa.com")
                        .role("ADMINISTRADOR")
                        .password("$2a$12$e8fH7z...HashSecretoPassword123!")
                        .secretApiKey("sk_live_998877665544332211_SUPER_SECRET_KEY")
                        .build();

                User dev = User.builder()
                        .username("juan_perez")
                        .email("juan.perez@empresa.com")
                        .role("DESARROLLADOR")
                        .password("$2a$12$9kX1yZ...HashJuan2025!")
                        .secretApiKey("sk_live_112233445566778899_DEVELOPER_KEY")
                        .build();

                userRepository.save(admin);
                userRepository.save(dev);
                System.out.println(">>> [INFO] Datos de prueba iniciales cargados en MySQL exitosamente.");
            }
        };
    }
}
