package com.security.demo.controller;

import com.security.demo.dto.UserDTO;
import com.security.demo.exception.GlobalExceptionHandler.UserNotFoundException;
import com.security.demo.model.User;
import com.security.demo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class UserController {

    private final UserRepository userRepository;

    /**
     * ❌ ENDPOINT VULNERABLE (Demuestra OWASP A02:2025 - Security Misconfiguration)
     * 
     * Problema 1: Exposición Excesiva de Datos (Data Overexposure)
     * Retorna la entidad directa 'User', exponiendo campos altamente sensibles como
     * la contraseña en hash 'password' y la clave secreta interna 'secretApiKey'.
     * 
     * Problema 2: Mala configuración de manejo de errores
     * Al fallar, lanza una excepción sin capturar, lo cual debido a la propiedad
     * 'server.error.include-stacktrace=always' expone detalles internos del servidor.
     */
    @GetMapping("/vulnerable/users/{id}")
    public User getVulnerableUser(@PathVariable Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Error interno de la aplicación. Ocurrió un fallo al buscar el ID: " + id +
                        ". Stacktrace expuesto por mala configuración de Spring Boot."));
    }

    /**
     * ✅ ENDPOINT MITIGADO (Aplica buenas prácticas de Seguridad)
     * 
     * Solución 1: Sanitización de datos mediante DTO (UserDTO)
     * Devuelve únicamente los campos públicos autorizados (id, username, email, role),
     * eliminando la contraseña y llaves secretas.
     * 
     * Solución 2: Manejo de errores estructurado y limpio
     * Lanza una UserNotFoundException que es capturada por GlobalExceptionHandler,
     * evitando la fuga de trazas internas o estructura de la base de datos.
     */
    @GetMapping("/mitigated/users/{id}")
    public ResponseEntity<UserDTO> getMitigatedUser(@PathVariable Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("El usuario con ID " + id + " no fue encontrado."));

        return ResponseEntity.ok(UserDTO.fromEntity(user));
    }
}
