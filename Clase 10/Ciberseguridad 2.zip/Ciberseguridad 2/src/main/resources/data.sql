-- Insertar usuario inicial de prueba con datos públicos y sensibles
INSERT IGNORE INTO users (id, username, email, role, password, secret_api_key) 
VALUES (1, 'admin_ciberseguridad', 'admin@empresa.com', 'ADMINISTRADOR', '$2a$12$e8fH7z...HashSecretoPassword123!', 'sk_live_998877665544332211_SUPER_SECRET_KEY');

INSERT IGNORE INTO users (id, username, email, role, password, secret_api_key) 
VALUES (2, 'juan_perez', 'juan.perez@empresa.com', 'DESARROLLADOR', '$2a$12$9kX1yZ...HashJuan2025!', 'sk_live_112233445566778899_DEVELOPER_KEY');
