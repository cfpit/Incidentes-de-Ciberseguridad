package com.ciberseguridad.incidentes;

import com.ciberseguridad.incidentes.proyecto3.dto.ComponentRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class CiberseguridadApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Carga correcta del contexto de la aplicación")
    void contextLoads() {
    }

    @Test
    @DisplayName("Proyecto 1 (IDOR - A01): Endpoint vulnerable permite acceso no autorizado")
    void testIdorVulnerableEndpoint() throws Exception {
        mockMvc.perform(get("/api/invoices/vulnerable/1")
                        .header("X-User-Name", "jorge_user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.ownerUsername").value("eri_dev"));
    }

    @Test
    @DisplayName("Proyecto 1 (IDOR - A01): Endpoint mitigado bloquea acceso si el usuario no es propietario")
    void testIdorMitigatedEndpointAccessDenied() throws Exception {
        mockMvc.perform(get("/api/invoices/secure/1")
                        .header("X-User-Name", "jorge_user"))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("Proyecto 1 (IDOR - A01): Endpoint mitigado permite acceso al propietario legítimo")
    void testIdorMitigatedEndpointAccessGranted() throws Exception {
        mockMvc.perform(get("/api/invoices/secure/1")
                        .header("X-User-Name", "eri_dev"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.ownerUsername").value("eri_dev"));
    }

    @Test
    @DisplayName("Proyecto 2 (Misconfiguration - A02): Endpoint mitigado retorna JSON limpio sin stacktrace")
    void testSecurityMisconfigurationMitigatedResponse() throws Exception {
        mockMvc.perform(get("/api/mitigated/users/999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.error").value("Recurso no encontrado"))
                .andExpect(jsonPath("$.mitigationNote").exists());
    }

    @Test
    @DisplayName("Proyecto 3 (Supply Chain Integrity - A03): Ingestión mitigada rechaza repositorio no autorizado")
    void testSupplyChainMitigationUntrustedRepo() throws Exception {
        String jsonPayload = """
                {
                    "name": "malicious-lib",
                    "version": "1.0.0",
                    "repositoryUrl": "https://untrusted-hacker-site.com/lib.jar",
                    "checksumSha256": "abc123hash",
                    "expectedSha256": "abc123hash"
                }
                """;

        mockMvc.perform(post("/api/components/mitigated")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonPayload))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.mode").value("MITIGATED"))
                .andExpect(jsonPath("$.component.status").value("REJECTED_UNTRUSTED_SUPPLIER"));
    }

    @Test
    @DisplayName("Proyecto 3 (Supply Chain Integrity - A03): Ingestión mitigada aprueba componente verificado")
    void testSupplyChainMitigationApprovedComponent() throws Exception {
        String jsonPayload = """
                {
                    "name": "jackson-databind",
                    "version": "2.15.0",
                    "repositoryUrl": "https://repo.maven.apache.org/maven2/jackson-databind.jar",
                    "checksumSha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
                    "expectedSha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
                }
                """;

        mockMvc.perform(post("/api/components/mitigated")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonPayload))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.component.status").value("INSTALLED"));
    }
}
