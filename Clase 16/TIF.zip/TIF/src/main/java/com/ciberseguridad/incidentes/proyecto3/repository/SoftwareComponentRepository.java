package com.ciberseguridad.incidentes.proyecto3.repository;

import com.ciberseguridad.incidentes.proyecto3.model.SoftwareComponent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SoftwareComponentRepository extends JpaRepository<SoftwareComponent, Long> {

    List<SoftwareComponent> findByInstallationModeOrderByCreatedAtDesc(String installationMode);

    List<SoftwareComponent> findAllByOrderByCreatedAtDesc();
}
