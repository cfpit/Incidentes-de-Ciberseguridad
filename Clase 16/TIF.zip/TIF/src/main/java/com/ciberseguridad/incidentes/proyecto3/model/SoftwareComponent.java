package com.ciberseguridad.incidentes.proyecto3.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "software_components")
public class SoftwareComponent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String version;

    @Column(nullable = false, length = 500)
    private String repositoryUrl;

    @Column(length = 64)
    private String declaredChecksum;

    @Column(length = 64)
    private String computedChecksum;

    private Boolean trustedSupplier;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ComponentStatus status;

    @Column(nullable = false)
    private String installationMode;

    @Column(length = 1000)
    private String validationDetails;

    private LocalDateTime createdAt;

    public SoftwareComponent() {}

    public SoftwareComponent(Long id, String name, String version, String repositoryUrl, String declaredChecksum, String computedChecksum, Boolean trustedSupplier, ComponentStatus status, String installationMode, String validationDetails, LocalDateTime createdAt) {
        this.id = id;
        this.name = name;
        this.version = version;
        this.repositoryUrl = repositoryUrl;
        this.declaredChecksum = declaredChecksum;
        this.computedChecksum = computedChecksum;
        this.trustedSupplier = trustedSupplier;
        this.status = status;
        this.installationMode = installationMode;
        this.validationDetails = validationDetails;
        this.createdAt = createdAt;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }

    public String getRepositoryUrl() { return repositoryUrl; }
    public void setRepositoryUrl(String repositoryUrl) { this.repositoryUrl = repositoryUrl; }

    public String getDeclaredChecksum() { return declaredChecksum; }
    public void setDeclaredChecksum(String declaredChecksum) { this.declaredChecksum = declaredChecksum; }

    public String getComputedChecksum() { return computedChecksum; }
    public void setComputedChecksum(String computedChecksum) { this.computedChecksum = computedChecksum; }

    public Boolean getTrustedSupplier() { return trustedSupplier; }
    public void setTrustedSupplier(Boolean trustedSupplier) { this.trustedSupplier = trustedSupplier; }

    public ComponentStatus getStatus() { return status; }
    public void setStatus(ComponentStatus status) { this.status = status; }

    public String getInstallationMode() { return installationMode; }
    public void setInstallationMode(String installationMode) { this.installationMode = installationMode; }

    public String getValidationDetails() { return validationDetails; }
    public void setValidationDetails(String validationDetails) { this.validationDetails = validationDetails; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    @PrePersist
    public void prePersist() {
        if (this.createdAt == null) {
            this.createdAt = LocalDateTime.now();
        }
    }

    public static SoftwareComponentBuilder builder() {
        return new SoftwareComponentBuilder();
    }

    public static class SoftwareComponentBuilder {
        private Long id;
        private String name;
        private String version;
        private String repositoryUrl;
        private String declaredChecksum;
        private String computedChecksum;
        private Boolean trustedSupplier;
        private ComponentStatus status;
        private String installationMode;
        private String validationDetails;
        private LocalDateTime createdAt;

        public SoftwareComponentBuilder id(Long id) { this.id = id; return this; }
        public SoftwareComponentBuilder name(String name) { this.name = name; return this; }
        public SoftwareComponentBuilder version(String version) { this.version = version; return this; }
        public SoftwareComponentBuilder repositoryUrl(String repositoryUrl) { this.repositoryUrl = repositoryUrl; return this; }
        public SoftwareComponentBuilder declaredChecksum(String declaredChecksum) { this.declaredChecksum = declaredChecksum; return this; }
        public SoftwareComponentBuilder computedChecksum(String computedChecksum) { this.computedChecksum = computedChecksum; return this; }
        public SoftwareComponentBuilder trustedSupplier(Boolean trustedSupplier) { this.trustedSupplier = trustedSupplier; return this; }
        public SoftwareComponentBuilder status(ComponentStatus status) { this.status = status; return this; }
        public SoftwareComponentBuilder installationMode(String installationMode) { this.installationMode = installationMode; return this; }
        public SoftwareComponentBuilder validationDetails(String validationDetails) { this.validationDetails = validationDetails; return this; }
        public SoftwareComponentBuilder createdAt(LocalDateTime createdAt) { this.createdAt = createdAt; return this; }

        public SoftwareComponent build() {
            return new SoftwareComponent(id, name, version, repositoryUrl, declaredChecksum, computedChecksum, trustedSupplier, status, installationMode, validationDetails, createdAt);
        }
    }
}
