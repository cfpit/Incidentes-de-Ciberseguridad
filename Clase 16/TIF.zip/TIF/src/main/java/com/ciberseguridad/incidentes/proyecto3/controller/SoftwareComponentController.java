package com.ciberseguridad.incidentes.proyecto3.controller;

import com.ciberseguridad.incidentes.proyecto3.dto.ComponentRequest;
import com.ciberseguridad.incidentes.proyecto3.dto.ValidationResponse;
import com.ciberseguridad.incidentes.proyecto3.model.SoftwareComponent;
import com.ciberseguridad.incidentes.proyecto3.service.SoftwareComponentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/components")
@CrossOrigin(origins = "*")
public class SoftwareComponentController {

    private final SoftwareComponentService service;

    public SoftwareComponentController(SoftwareComponentService service) {
        this.service = service;
    }

    @PostMapping("/vulnerable")
    public ResponseEntity<ValidationResponse> registerVulnerable(@RequestBody ComponentRequest request) {
        ValidationResponse response = service.processVulnerableIngestion(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/mitigated")
    public ResponseEntity<ValidationResponse> registerMitigated(@RequestBody ComponentRequest request) {
        ValidationResponse response = service.processMitigatedIngestion(request);
        if (!response.isSuccess()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<List<SoftwareComponent>> getAllComponents() {
        return ResponseEntity.ok(service.getAllComponents());
    }

    @DeleteMapping
    public ResponseEntity<String> clearDatabase() {
        service.clearAll();
        return ResponseEntity.ok("Base de datos limpiada correctamente.");
    }
}
