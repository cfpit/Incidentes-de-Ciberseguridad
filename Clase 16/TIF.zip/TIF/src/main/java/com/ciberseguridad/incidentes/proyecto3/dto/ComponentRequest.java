package com.ciberseguridad.incidentes.proyecto3.dto;

public class ComponentRequest {

    private String name;
    private String version;
    private String repositoryUrl;
    private String checksumSha256;
    private String expectedSha256;

    public ComponentRequest() {}

    public ComponentRequest(String name, String version, String repositoryUrl, String checksumSha256, String expectedSha256) {
        this.name = name;
        this.version = version;
        this.repositoryUrl = repositoryUrl;
        this.checksumSha256 = checksumSha256;
        this.expectedSha256 = expectedSha256;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }

    public String getRepositoryUrl() { return repositoryUrl; }
    public void setRepositoryUrl(String repositoryUrl) { this.repositoryUrl = repositoryUrl; }

    public String getChecksumSha256() { return checksumSha256; }
    public void setChecksumSha256(String checksumSha256) { this.checksumSha256 = checksumSha256; }

    public String getExpectedSha256() { return expectedSha256; }
    public void setExpectedSha256(String expectedSha256) { this.expectedSha256 = expectedSha256; }
}
