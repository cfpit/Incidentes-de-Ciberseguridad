package com.ciberseguridad.incidentes.proyecto3.service;

import com.ciberseguridad.incidentes.proyecto3.dto.ComponentRequest;
import com.ciberseguridad.incidentes.proyecto3.dto.ValidationResponse;
import com.ciberseguridad.incidentes.proyecto3.model.ComponentStatus;
import com.ciberseguridad.incidentes.proyecto3.model.SoftwareComponent;
import com.ciberseguridad.incidentes.proyecto3.repository.SoftwareComponentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Service
public class SoftwareComponentService {

    private static final Logger log = LoggerFactory.getLogger(SoftwareComponentService.class);

    private final SoftwareComponentRepository repository;

    public SoftwareComponentService(SoftwareComponentRepository repository) {
        this.repository = repository;
    }

    private static final List<String> TRUSTED_DOMAINS = Arrays.asList(
            "repo.maven.apache.org",
            "registry.npmjs.org",
            "pypi.org",
            "trusted-enterprise.internal"
    );

    public ValidationResponse processVulnerableIngestion(ComponentRequest request) {
        log.warn("[VULNERABLE A03:2025] Ingestando componente sin verificación de cadena de suministro: {}", request.getName());

        SoftwareComponent component = SoftwareComponent.builder()
                .name(request.getName())
                .version(request.getVersion())
                .repositoryUrl(request.getRepositoryUrl())
                .declaredChecksum(request.getChecksumSha256())
                .computedChecksum(request.getChecksumSha256())
                .trustedSupplier(false)
                .status(ComponentStatus.INSTALLED)
                .installationMode("VULNERABLE_INGESTION")
                .validationDetails("ADVERTENCIA A03:2025: Componente instalado sin validar hash SHA-256 ni dominio de origen.")
                .createdAt(LocalDateTime.now())
                .build();

        SoftwareComponent saved = repository.save(component);

        return ValidationResponse.builder()
                .success(true)
                .mode("VULNERABLE")
                .message("Componente instalado exitosamente (¡SIN CONTROLES DE SEGURIDAD!)")
                .vulnerabilityExplanation("OWASP A03:2025 Fallo detectado: La aplicación aceptó el artefacto directamente de '" 
                        + request.getRepositoryUrl() + "' sin comprobar su hash oficial ni verificar si el proveedor era confiable. "
                        + "Esto permite ataques de envenenamiento de código, typosquatting o sustitución de artefactos maliciosos.")
                .component(saved)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public ValidationResponse processMitigatedIngestion(ComponentRequest request) {
        log.info("[MITIGADO A03:2025] Evaluando seguridad de cadena de suministro para: {}", request.getName());

        String repoUrl = request.getRepositoryUrl() != null ? request.getRepositoryUrl() : "";
        boolean isDomainTrusted = TRUSTED_DOMAINS.stream().anyMatch(repoUrl::contains);

        if (!isDomainTrusted) {
            log.error("[MITIGACIÓN FALLIDA] Dominio no autorizado en repositorio: {}", repoUrl);

            SoftwareComponent rejectedComponent = SoftwareComponent.builder()
                    .name(request.getName())
                    .version(request.getVersion())
                    .repositoryUrl(request.getRepositoryUrl())
                    .declaredChecksum(request.getChecksumSha256())
                    .computedChecksum(null)
                    .trustedSupplier(false)
                    .status(ComponentStatus.REJECTED_UNTRUSTED_SUPPLIER)
                    .installationMode("MITIGATED_INGESTION")
                    .validationDetails("RECHAZADO: El repositorio '" + repoUrl + "' no está en la lista blanca de proveedores autorizados.")
                    .createdAt(LocalDateTime.now())
                    .build();

            SoftwareComponent savedRejected = repository.save(rejectedComponent);

            return ValidationResponse.builder()
                    .success(false)
                    .mode("MITIGATED")
                    .message("Instalación Bloqueada por Control de Cadena de Suministro")
                    .vulnerabilityExplanation("Seguridad A03:2025 Activa: El repositorio de origen (" + repoUrl + ") NO pertenece a la lista blanca corporativa. Se previene la inyección de componentes maliciosos no auditados.")
                    .component(savedRejected)
                    .timestamp(LocalDateTime.now())
                    .build();
        }

        String declaredHash = request.getChecksumSha256();
        String expectedHash = request.getExpectedSha256();

        if (expectedHash != null && !expectedHash.isBlank() && !expectedHash.equalsIgnoreCase(declaredHash)) {
            log.error("[MITIGACIÓN FALLIDA] Discrepancia de SHA-256. Declarado: {}, Esperado: {}", declaredHash, expectedHash);

            SoftwareComponent tamperedComponent = SoftwareComponent.builder()
                    .name(request.getName())
                    .version(request.getVersion())
                    .repositoryUrl(request.getRepositoryUrl())
                    .declaredChecksum(declaredHash)
                    .computedChecksum(expectedHash)
                    .trustedSupplier(true)
                    .status(ComponentStatus.REJECTED_CHECKSUM_MISMATCH)
                    .installationMode("MITIGATED_INGESTION")
                    .validationDetails("RECHAZADO POR INTEGRIDAD: El hash SHA-256 del archivo descargado (" + declaredHash + ") NO coincide con el hash del lockfile verificado (" + expectedHash + ").")
                    .createdAt(LocalDateTime.now())
                    .build();

            SoftwareComponent savedTampered = repository.save(tamperedComponent);

            return ValidationResponse.builder()
                    .success(false)
                    .mode("MITIGATED")
                    .message("Instalación Rechazada: Alteración de Integridad Detectada (SHA-256 Mismatch)")
                    .vulnerabilityExplanation("Seguridad A03:2025 Activa: El hash del paquete recibido fue alterado o envenenado. Se bloqueó la instalación automáticamente.")
                    .component(savedTampered)
                    .timestamp(LocalDateTime.now())
                    .build();
        }

        SoftwareComponent validComponent = SoftwareComponent.builder()
                .name(request.getName())
                .version(request.getVersion())
                .repositoryUrl(request.getRepositoryUrl())
                .declaredChecksum(declaredHash)
                .computedChecksum(declaredHash)
                .trustedSupplier(true)
                .status(ComponentStatus.INSTALLED)
                .installationMode("MITIGATED_INGESTION")
                .validationDetails("VERIFICADO CON ÉXITO: Proveedor verificado en lista blanca y Hash SHA-256 validado contra el SBOM/lockfile.")
                .createdAt(LocalDateTime.now())
                .build();

        SoftwareComponent savedValid = repository.save(validComponent);

        return ValidationResponse.builder()
                .success(true)
                .mode("MITIGATED")
                .message("Componente Aprobado e Instalado de Forma Segura")
                .vulnerabilityExplanation("Control OWASP A03:2025 Cumplido: El componente superó la validación de proveedor confiable y la verificación cryptographic hash SHA-256.")
                .component(savedValid)
                .timestamp(LocalDateTime.now())
                .build();
    }

    public List<SoftwareComponent> getAllComponents() {
        return repository.findAllByOrderByCreatedAtDesc();
    }

    public void clearAll() {
        repository.deleteAll();
    }
}
