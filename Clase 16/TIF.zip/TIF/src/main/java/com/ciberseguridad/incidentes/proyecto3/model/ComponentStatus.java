package com.ciberseguridad.incidentes.proyecto3.model;

public enum ComponentStatus {
    INSTALLED,
    REJECTED_UNTRUSTED_SUPPLIER,
    REJECTED_CHECKSUM_MISMATCH,
    REJECTED_MALICIOUS_CONTAINER
}
