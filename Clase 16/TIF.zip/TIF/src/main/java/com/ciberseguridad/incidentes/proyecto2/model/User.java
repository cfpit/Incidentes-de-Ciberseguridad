package com.ciberseguridad.incidentes.proyecto2.model;

import jakarta.persistence.*;
@Entity
@Table(name = "users")
public class User {

    public User() {}

    public User(Long id, String username, String email, String role, String password, String secretApiKey) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.role = role;
        this.password = password;
        this.secretApiKey = secretApiKey;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String role;

    @Column(nullable = false)
    private String password;

    @Column(name = "secret_api_key", nullable = false)
    private String secretApiKey;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getSecretApiKey() { return secretApiKey; }
    public void setSecretApiKey(String secretApiKey) { this.secretApiKey = secretApiKey; }

    public static UserBuilder builder() {
        return new UserBuilder();
    }

    public static class UserBuilder {
        private Long id;
        private String username;
        private String email;
        private String role;
        private String password;
        private String secretApiKey;

        public UserBuilder id(Long id) { this.id = id; return this; }
        public UserBuilder username(String username) { this.username = username; return this; }
        public UserBuilder email(String email) { this.email = email; return this; }
        public UserBuilder role(String role) { this.role = role; return this; }
        public UserBuilder password(String password) { this.password = password; return this; }
        public UserBuilder secretApiKey(String secretApiKey) { this.secretApiKey = secretApiKey; return this; }

        public User build() {
            return new User(id, username, email, role, password, secretApiKey);
        }
    }
}
