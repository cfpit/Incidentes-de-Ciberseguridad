package com.ciberseguridad.incidentes.proyecto2.controller;

import com.ciberseguridad.incidentes.proyecto2.dto.UserDTO;
import com.ciberseguridad.incidentes.proyecto2.exception.GlobalExceptionHandler.UserNotFoundException;
import com.ciberseguridad.incidentes.proyecto2.model.User;
import com.ciberseguridad.incidentes.proyecto2.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserController {

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/vulnerable/users/{id}")
    public User getVulnerableUser(@PathVariable Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Error interno de la aplicación. Ocurrió un fallo al buscar el ID: " + id +
                        ". Stacktrace expuesto por mala configuración de Spring Boot."));
    }

    @GetMapping("/mitigated/users/{id}")
    public ResponseEntity<UserDTO> getMitigatedUser(@PathVariable Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("El usuario con ID " + id + " no fue encontrado."));

        return ResponseEntity.ok(UserDTO.fromEntity(user));
    }
}
