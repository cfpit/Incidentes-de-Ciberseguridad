package com.ciberseguridad.incidentes.proyecto3.dto;

import com.ciberseguridad.incidentes.proyecto3.model.SoftwareComponent;
import java.time.LocalDateTime;

public class ValidationResponse {

    private boolean success;
    private String mode; // VULNERABLE or MITIGATED
    private String message;
    private String vulnerabilityExplanation;
    private SoftwareComponent component;
    private LocalDateTime timestamp;

    public ValidationResponse() {}

    public ValidationResponse(boolean success, String mode, String message, String vulnerabilityExplanation, SoftwareComponent component, LocalDateTime timestamp) {
        this.success = success;
        this.mode = mode;
        this.message = message;
        this.vulnerabilityExplanation = vulnerabilityExplanation;
        this.component = component;
        this.timestamp = timestamp;
    }

    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }

    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getVulnerabilityExplanation() { return vulnerabilityExplanation; }
    public void setVulnerabilityExplanation(String vulnerabilityExplanation) { this.vulnerabilityExplanation = vulnerabilityExplanation; }

    public SoftwareComponent getComponent() { return component; }
    public void setComponent(SoftwareComponent component) { this.component = component; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public static ValidationResponseBuilder builder() {
        return new ValidationResponseBuilder();
    }

    public static class ValidationResponseBuilder {
        private boolean success;
        private String mode;
        private String message;
        private String vulnerabilityExplanation;
        private SoftwareComponent component;
        private LocalDateTime timestamp;

        public ValidationResponseBuilder success(boolean success) { this.success = success; return this; }
        public ValidationResponseBuilder mode(String mode) { this.mode = mode; return this; }
        public ValidationResponseBuilder message(String message) { this.message = message; return this; }
        public ValidationResponseBuilder vulnerabilityExplanation(String vulnerabilityExplanation) { this.vulnerabilityExplanation = vulnerabilityExplanation; return this; }
        public ValidationResponseBuilder component(SoftwareComponent component) { this.component = component; return this; }
        public ValidationResponseBuilder timestamp(LocalDateTime timestamp) { this.timestamp = timestamp; return this; }

        public ValidationResponse build() {
            return new ValidationResponse(success, mode, message, vulnerabilityExplanation, component, timestamp);
        }
    }
}
