-- Proyecto 1: Registro de Facturas para OWASP A01 (IDOR)
INSERT IGNORE INTO invoice (id, client_name, amount, owner_username) VALUES (1, 'Empresa Alfa (Coca-Cola Argentina)', 150000.0, 'eri_dev');
INSERT IGNORE INTO invoice (id, client_name, amount, owner_username) VALUES (2, 'Empresa Beta (Pepsi Co)', 85000.0, 'jorge_user');

-- Proyecto 2: Registros de Usuarios de Prueba para OWASP A02 (Security Misconfiguration)
INSERT IGNORE INTO users (id, username, email, role, password, secret_api_key) 
VALUES (1, 'admin_ciberseguridad', 'admin@empresa.com', 'ADMINISTRADOR', '$2a$12$e8fH7z...HashSecretoPassword123!', 'sk_live_998877665544332211_SUPER_SECRET_KEY');

INSERT IGNORE INTO users (id, username, email, role, password, secret_api_key) 
VALUES (2, 'juan_perez', 'juan.perez@empresa.com', 'DESARROLLADOR', '$2a$12$9kX1yZ...HashJuan2025!', 'sk_live_112233445566778899_DEVELOPER_KEY');
