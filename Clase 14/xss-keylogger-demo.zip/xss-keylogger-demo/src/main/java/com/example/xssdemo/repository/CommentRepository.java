package com.example.xssdemo.repository;

import com.example.xssdemo.model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByIsMitigatedOrderByIdDesc(Boolean isMitigated);

    List<Comment> findAllByOrderByIdDesc();
}

/*
 * EXPLICACIÓN DE LOS MÉTODOS DE CONSULTA DERIVADOS (Spring Data JPA Query
 * Methods):
 *
 * 1. findByIsMitigatedOrderByIdDesc(Boolean isMitigated):
 * - Genera automáticamente la consulta SQL:
 * SELECT * FROM comments WHERE is_mitigated = ? ORDER BY id DESC;
 * - Sirve para filtrar comentarios:
 * * Con false: trae solo los comentarios vulnerables
 * (/api/vulnerable/comments).
 * * Con true: trae solo los comentarios sanitizados (/api/mitigated/comments).
 * - OrderByIdDesc asegura que los comentarios más recientes aparezcan primero.
 *
 * 2. findAllByOrderByIdDesc():
 * - Genera automáticamente la consulta SQL:
 * SELECT * FROM comments ORDER BY id DESC;
 * - Trae todos los comentarios guardados en la tabla (vulnerables y mitigados),
 * ordenados del más reciente al más antiguo.
 */
