package ar.edu.centro8.ic.dinamico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DinamicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
