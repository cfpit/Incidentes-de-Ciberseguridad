package ar.edu.centro8.ic.dinamico.controller;
import ar.edu.centro8.ic.dinamico.model.Cliente;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;

@RestController
public class SaludoController {
    //endpoint para saludar
    //http://localhost:8080/saludo
    @GetMapping("/saludo")
    public String saludo() {
        return "¡Hola, mundo!";
    }

    //uso de PathVariable
    //http://localhost:8080/saludo/juan/perez/30
    @GetMapping("/saludo/{nombre}/{apellido}/{edad}")
    public String saludoNombre(@PathVariable String nombre, @PathVariable String apellido, @PathVariable int edad) {
        return "¡Hola, " + nombre + " " + apellido + "! Tienes " + edad + " años.";
    }
    
    //uso de RequestParam
    //http://localhost:8080/saludo2?nombre=Maria&apellido=Garcia&edad=40
    @GetMapping("/saludo2")
    public String saludoNombre2(@RequestParam String nombre, @RequestParam String apellido, @RequestParam int edad) {
        return "¡Como estas, " + nombre + " " + apellido + " tu edad es de " + edad + " años.";
    }

    //PostMapping
    //http://localhost:8080/cliente
    /*
        Desde el body de la request en Postman(cliente HTTP) se envia un objeto JSON  de la siguiente manera:
        {
            "nombre": "Juan",
            "edad": 30
        }
    */
    @PostMapping("/cliente")
    public String saludoNombre3(@RequestBody Cliente c) {
        return "¡Hola, " + c.getNombre() + "! Tienes " + c.getEdad() + " años.";
    }



    
}
