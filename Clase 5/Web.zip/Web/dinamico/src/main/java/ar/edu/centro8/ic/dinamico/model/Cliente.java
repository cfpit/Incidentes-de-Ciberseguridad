package ar.edu.centro8.ic.dinamico.model;
// import lombok.ToString;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
// @ToString
// @Data
public class Cliente {
    private String nombre;
    private int edad;
}
