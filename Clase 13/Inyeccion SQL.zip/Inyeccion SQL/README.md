# 🛡️ Laboratorio de Inyección SQL - OWASP A05:2025

Este proyecto es una aplicación desarrollada en **Spring Boot 3** conectada a **MySQL**, diseñada con fines educativos para analizar y comprender la vulnerabilidad **OWASP A05:2025 - Inyección SQL (Injection)** mediante la comparación directa entre endpoints **vulnerables** y **mitigados**.

---

## 📑 Tabla de Contenidos
1. [¿Qué es la Inyección SQL (OWASP A05:2025)?](#-qué-es-la-inyección-sql-owasp-a052025)
2. [Arquitectura del Proyecto](#-arquitectura-del-proyecto)
3. [Dependencias Utilizadas (pom.xml)](#-dependencias-utilizadas-pomxml)
4. [Configuración de Base de Datos (MySQL)](#-configuración-de-base-de-datos-mysql)
5. [Cómo Ejecutar el Proyecto](#-cómo-ejecutar-el-proyecto)
6. [Interfaz Gráfica Web](#-interfaz-gráfica-web)
7. [Rutas y Pruebas en Postman / Bruno / cURL](#-rutas-y-pruebas-en-postman--bruno--curl)
8. [Explicación del Código: Vulnerable vs Mitigado](#-explicación-del-código-vulnerable-vs-mitigado)

---

## 🔍 ¿Qué es la Inyección SQL (OWASP A05:2025)?

La **Inyección SQL** ocurre cuando los datos proporcionados por un usuario se concatenan directamente dentro de una consulta SQL sin validación ni parametrización previa.

- **Causa raíz:** Tratar la entrada del usuario como parte ejecutable de la sentencia SQL.
- **Impacto:** Robo de información confidencial, evasión de autenticación (login bypass), modificación o destrucción de datos (DROP / DELETE), y en algunos casos ejecución remota de comandos.
- **Solución / Mitigación:** Utilizar **Consultas Parametrizadas (PreparedStatements)** o métodos seguros de ORM/JPA donde la base de datos compila la consulta primero y trata la entrada estrictamente como datos literales.

---

## 🏗️ Arquitectura del Proyecto

El proyecto sigue el patrón de arquitectura por capas estándar en Spring Boot:

```
src/main/java/com/ejemplo/sqlinjection/
│
├── controller/
│   └── UsuarioController.java       # Expone endpoints REST (vulnerables y mitigados)
│
├── service/
│   └── UsuarioService.java          # Contiene la lógica de negocio y ejecución SQL
│
├── repository/
│   └── UsuarioRepository.java       # Interfaz JPA con consultas parametrizadas
│
├── model/
│   └── Usuario.java                 # Entidad JPA para la tabla 'usuarios'
│
├── dto/
│   └── SqlResultResponse.java       # Formato de respuesta JSON detallado para análisis
│
└── SqlInjectionApplication.java     # Clase principal y precarga de datos iniciales
```

Frontend estático:
```
src/main/resources/static/
└── index.html                       # Panel interactivo web para probar ataques y defensas
```

---

## 📦 Dependencias Utilizadas (pom.xml)

- **Spring Web** (`spring-boot-starter-web`): Controladores REST y servidor embebido Tomcat.
- **Spring Data JPA** (`spring-boot-starter-data-jpa`): Persistencia y abstracción de base de datos con Hibernate.
- **MySQL Driver** (`mysql-connector-j`): Conector JDBC para base de datos MySQL.
- **Spring Boot DevTools** (`spring-boot-devtools`): Reinicio y recarga automática durante el desarrollo.
- **Lombok** (`lombok`): Generación automática de Getters, Setters, constructores y patrón Builder.

---

## 🗄️ Configuración de Base de Datos (MySQL)

Configurado en [src/main/resources/application.properties](src/main/resources/application.properties):

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/sqlinjection_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=root
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
```

> **Nota:** Modifica `spring.datasource.username` y `spring.datasource.password` con las credenciales de tu servidor MySQL local si son distintas.

### Datos de Prueba Precargados Automáticamente
Al iniciar la aplicación, se insertan los siguientes registros de prueba si la tabla está vacía:

| ID | Username | Password | Email | Rol | Saldo |
|---|---|---|---|---|---|
| 1 | `admin` | `admin123` | `administrador@empresa.com` | ADMIN | $5000.00 |
| 2 | `juan_perez` | `claveJuan2024` | `juan.perez@empresa.com` | USER | $1800.50 |
| 3 | `maria_gomez` | `mariaSecret!` | `maria.gomez@empresa.com` | USER | $2200.00 |
| 4 | `carlos_ruiz` | `carlosPass99` | `carlos.ruiz@empresa.com` | MANAGER | $3500.75 |

---

## 🚀 Cómo Ejecutar el Proyecto

1. Asegúrate de tener **MySQL** iniciado en el puerto `3306`.
2. Compila y ejecuta la aplicación con Maven:
   ```bash
   mvn clean spring-boot:run
   ```
3. La aplicación estará escuchando en `http://localhost:8080`.

---

## 🌐 Interfaz Gráfica Web

Abre tu navegador en:
```
http://localhost:8080
```
La interfaz estática permite:
1. Probar en tiempo real el endpoint vulnerable frente al mitigado.
2. Inyectar payloads comunes con un solo clic.
3. Observar la sentencia SQL construida y por qué tuvo éxito o falló.
4. Ver todos los registros actuales de MySQL y restaurar los datos de prueba.

---

## 📡 Rutas y Pruebas en Postman / Bruno / cURL

### 🔴 1. Endpoints Vulnerables (Inyección Exitosa)

#### 1.1 Login Bypass (Evasión de Contraseña)
- **Método:** `GET`
- **URL:** `http://localhost:8080/api/vulnerable/login`
- **Query Params:**
  - `username`: `admin' -- `
  - `password`: `cualquiera`

**Ejemplo cURL:**
```bash
curl "http://localhost:8080/api/vulnerable/login?username=admin'%20--%20&password=x"
```

**Explicación:** La consulta resultante en MySQL es:
```sql
SELECT * FROM usuarios WHERE username = 'admin' -- ' AND password = 'x'
```
Los dos guiones `--` comentan el resto de la consulta, por lo que la comprobación de la contraseña queda anulada y el atacante ingresa como `admin`.

---

#### 1.2 Extracción de todos los registros (Bypass Booleano)
- **Método:** `GET`
- **URL:** `http://localhost:8080/api/vulnerable/login`
- **Query Params:**
  - `username`: `' OR '1'='1`
  - `password`: `' OR '1'='1`

**Ejemplo cURL:**
```bash
curl "http://localhost:8080/api/vulnerable/login?username='%20OR%20'1'='1&password='%20OR%20'1'='1"
```

**Explicación:** La condición `'1'='1'` siempre es verdadera, devolviendo toda la tabla de usuarios con sus saldos y contraseñas.

---

#### 1.3 Búsqueda Vulnerable
- **Método:** `GET`
- **URL:** `http://localhost:8080/api/vulnerable/buscar`
- **Query Params:**
  - `termino`: `' OR '1'='1`

**Ejemplo cURL:**
```bash
curl "http://localhost:8080/api/vulnerable/buscar?termino='%20OR%20'1'='1"
```

---

### 🟢 2. Endpoints Mitigados (Inyección Bloqueada / Segura)

#### 2.1 Intento de Ataque contra Endpoint Mitigado
- **Método:** `GET`
- **URL:** `http://localhost:8080/api/mitigado/login`
- **Query Params:**
  - `username`: `admin' -- `
  - `password`: `cualquiera`

**Ejemplo cURL:**
```bash
curl "http://localhost:8080/api/mitigado/login?username=admin'%20--%20&password=x"
```

**Resultado:** `0 registros`. El motor de base de datos busca literalmente a un usuario cuyo nombre sea `"admin' -- "` y no interpreta los caracteres como sintaxis SQL.

#### 2.2 Login Legítimo en Endpoint Mitigado
- **Método:** `GET`
- **URL:** `http://localhost:8080/api/mitigado/login`
- **Query Params:**
  - `username`: `admin`
  - `password`: `admin123`

**Ejemplo cURL:**
```bash
curl "http://localhost:8080/api/mitigado/login?username=admin&password=admin123"
```

**Resultado:** Autenticación exitosa del usuario `admin`.

---

### 📋 3. Endpoints de Utilidad

#### Listar todos los usuarios
- `GET http://localhost:8080/api/usuarios`

#### Restaurar datos iniciales
- `POST http://localhost:8080/api/usuarios/reset`

---

## 💻 Explicación del Código: Vulnerable vs Mitigado

### ❌ Código Inseguro (Concatenación Directa)
Localizado en [src/main/java/com/ejemplo/sqlinjection/service/UsuarioService.java](src/main/java/com/ejemplo/sqlinjection/service/UsuarioService.java):
```java
// INSEGURO: Permite alterar la estructura de la consulta
String sql = "SELECT * FROM usuarios WHERE username = '" + username + "' AND password = '" + password + "'";
List<Usuario> resultados = entityManager.createNativeQuery(sql, Usuario.class).getResultList();
```

### ✔️ Código Seguro (Consultas Parametrizadas)
Localizado en [src/main/java/com/ejemplo/sqlinjection/repository/UsuarioRepository.java](src/main/java/com/ejemplo/sqlinjection/repository/UsuarioRepository.java):
```java
// SEGURO: Parameter Binding con PreparedStatement
Optional<Usuario> findByUsernameAndPassword(String username, String password);

// O mediante JPQL con parámetros nombrados:
@Query("SELECT u FROM Usuario u WHERE u.username = :username AND u.password = :password")
Optional<Usuario> findByCredentialsSecure(@Param("username") String username, @Param("password") String password);
```
