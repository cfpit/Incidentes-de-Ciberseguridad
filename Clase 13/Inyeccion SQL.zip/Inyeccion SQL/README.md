# 🛡️ Laboratorio de Inyección SQL - OWASP A05:2025

Este proyecto es una aplicación desarrollada en **Spring Boot 3** conectada a **MySQL**, diseñada con fines educativos para analizar y comprender la vulnerabilidad **OWASP A05:2025 - Inyección SQL (Injection)** mediante la comparación directa entre endpoints **vulnerables** y **mitigados**.

---

## 📑 Tabla de Contenidos

1. [¿Qué es la Inyección SQL (OWASP A05:2025)?](#-qué-es-la-inyección-sql-owasp-a052025)
2. [Arquitectura del Proyecto](#-arquitectura-del-proyecto)
3. [Dependencias Utilizadas (pom.xml)](#-dependencias-utilizadas-pomxml)
4. [Configuración de Base de Datos (MySQL)](#-configuración-de-base-de-datos-mysql)
5. [Cómo Ejecutar el Proyecto](#-cómo-ejecutar-el-proyecto)
6. [Interfaz Gráfica Web](#-interfaz-gráfica-web)
7. [Rutas y Pruebas en Postman / Bruno / cURL](#-rutas-y-pruebas-en-postman--bruno--curl)
8. [Explicación del Código: Vulnerable vs Mitigado](#-explicación-del-código-vulnerable-vs-mitigado)
9. [Guía Rápida de Pruebas en el Front-End (localhost:8080)](#-guía-rápida-de-pruebas-en-el-front-end-localhost8080)

---

## 🔍 ¿Qué es la Inyección SQL (OWASP A05:2025)?

La **Inyección SQL** ocurre cuando los datos proporcionados por un usuario se concatenan directamente dentro de una consulta SQL sin validación ni parametrización previa.

- **Causa raíz:** Tratar la entrada del usuario como parte ejecutable de la sentencia SQL.
- **Impacto:** Robo de información confidencial, evasión de autenticación (login bypass), modificación o destrucción de datos (DROP / DELETE), y en algunos casos ejecución remota de comandos.
- **Solución / Mitigación:** Utilizar **Consultas Parametrizadas (PreparedStatements)** o métodos seguros de ORM/JPA donde la base de datos compila la consulta primero y trata la entrada estrictamente como datos literales.

---

## 🏗️ Arquitectura del Proyecto

El proyecto sigue el patrón de arquitectura por capas estándar en Spring Boot:

```
src/main/java/com/ejemplo/sqlinjection/
│
├── controller/
│   └── UsuarioController.java       # Expone endpoints REST (vulnerables y mitigados)
│
├── service/
│   └── UsuarioService.java          # Contiene la lógica de negocio y ejecución SQL
│
├── repository/
│   └── UsuarioRepository.java       # Interfaz JPA con consultas parametrizadas
│
├── model/
│   └── Usuario.java                 # Entidad JPA para la tabla 'usuarios'
│
├── dto/
│   └── SqlResultResponse.java       # Formato de respuesta JSON detallado para análisis
│
└── SqlInjectionApplication.java     # Clase principal y precarga de datos iniciales
```

Frontend estático:

```
src/main/resources/static/
└── index.html                       # Panel interactivo web para probar ataques y defensas
```

---

## 📦 Dependencias Utilizadas (pom.xml)

- **Spring Web** (`spring-boot-starter-web`): Controladores REST y servidor embebido Tomcat.
- **Spring Data JPA** (`spring-boot-starter-data-jpa`): Persistencia y abstracción de base de datos con Hibernate.
- **MySQL Driver** (`mysql-connector-j`): Conector JDBC para base de datos MySQL.
- **Spring Boot DevTools** (`spring-boot-devtools`): Reinicio y recarga automática durante el desarrollo.
- **Lombok** (`lombok`): Generación automática de Getters, Setters, constructores y patrón Builder.

---

## 🗄️ Configuración de Base de Datos (MySQL)

Configurado en [src/main/resources/application.properties](src/main/resources/application.properties):

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/sqlinjection_db?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=root
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
```

> **Nota:** Modifica `spring.datasource.username` y `spring.datasource.password` con las credenciales de tu servidor MySQL local si son distintas.

### Datos de Prueba Precargados Automáticamente

Al iniciar la aplicación, se insertan los siguientes registros de prueba si la tabla está vacía:

| ID | Username        | Password          | Email                         | Rol     | Saldo    |
| -- | --------------- | ----------------- | ----------------------------- | ------- | -------- |
| 1  | `admin`       | `admin123`      | `administrador@empresa.com` | ADMIN   | $5000.00 |
| 2  | `juan_perez`  | `claveJuan2024` | `juan.perez@empresa.com`    | USER    | $1800.50 |
| 3  | `maria_gomez` | `mariaSecret!`  | `maria.gomez@empresa.com`   | USER    | $2200.00 |
| 4  | `carlos_ruiz` | `carlosPass99`  | `carlos.ruiz@empresa.com`   | MANAGER | $3500.75 |

---

## 🚀 Cómo Ejecutar el Proyecto

1. Asegúrate de tener **MySQL** iniciado en el puerto `3306`.
2. Compila y ejecuta la aplicación con Maven:
   ```bash
   mvn clean spring-boot:run
   ```
3. La aplicación estará escuchando en `http://localhost:8080`.

---

## 🌐 Interfaz Gráfica Web

Abre tu navegador en:

```
http://localhost:8080
```

La interfaz estática permite:

1. Probar en tiempo real el endpoint vulnerable frente al mitigado.
2. Inyectar payloads comunes con un solo clic.
3. Observar la sentencia SQL construida y por qué tuvo éxito o falló.
4. Ver todos los registros actuales de MySQL y restaurar los datos de prueba.

---

## 📡 Rutas y Pruebas en Postman / Bruno / cURL

### 🔴 1. Endpoints Vulnerables (Inyección Exitosa)

#### 1.1 Login Bypass (Evasión de Contraseña)

- **Método:** `GET`
- **URL:** `http://localhost:8080/api/vulnerable/login`
- **Query Params:**
  - `username`: `admin' -- `
  - `password`: `cualquiera`

**Ejemplo cURL:**

```bash
curl "http://localhost:8080/api/vulnerable/login?username=admin'%20--%20&password=x"
```

**Explicación:** La consulta resultante en MySQL es:

```sql
SELECT * FROM usuarios WHERE username = 'admin' -- ' AND password = 'x'
```

Los dos guiones `--` comentan el resto de la consulta, por lo que la comprobación de la contraseña queda anulada y el atacante ingresa como `admin`.

---

#### 1.2 Extracción de todos los registros (Bypass Booleano)

- **Método:** `GET`
- **URL:** `http://localhost:8080/api/vulnerable/login`
- **Query Params:**
  - `username`: `' OR '1'='1`
  - `password`: `		`

**Ejemplo cURL:**

```bash
curl "http://localhost:8080/api/vulnerable/login?username='%20OR%20'1'='1&password='%20OR%20'1'='1"
```

**Explicación:** La condición `'1'='1'` siempre es verdadera, devolviendo toda la tabla de usuarios con sus saldos y contraseñas.

---

#### 1.3 Búsqueda Vulnerable

- **Método:** `GET`
- **URL:** `http://localhost:8080/api/vulnerable/buscar`
- **Query Params:**
  - `termino`: `' OR '1'='1`

**Ejemplo cURL:**

```bash
curl "http://localhost:8080/api/vulnerable/buscar?termino='%20OR%20'1'='1"
```

---

### 🟢 2. Endpoints Mitigados (Inyección Bloqueada / Segura)

#### 2.1 Intento de Ataque contra Endpoint Mitigado

- **Método:** `GET`
- **URL:** `http://localhost:8080/api/mitigado/login`
- **Query Params:**
  - `username`: `admin' -- `
  - `password`: `cualquiera`

**Ejemplo cURL:**

```bash
curl "http://localhost:8080/api/mitigado/login?username=admin'%20--%20&password=x"
```

**Resultado:** `0 registros`. El motor de base de datos busca literalmente a un usuario cuyo nombre sea `"admin' -- "` y no interpreta los caracteres como sintaxis SQL.

#### 2.2 Login Legítimo en Endpoint Mitigado

- **Método:** `GET`
- **URL:** `http://localhost:8080/api/mitigado/login`
- **Query Params:**
  - `username`: `admin`
  - `password`: `admin123`

**Ejemplo cURL:**

```bash
curl "http://localhost:8080/api/mitigado/login?username=admin&password=admin123"
```

**Resultado:** Autenticación exitosa del usuario `admin`.

---

### 📋 3. Endpoints de Utilidad

#### Listar todos los usuarios

- `GET http://localhost:8080/api/usuarios`

#### Restaurar datos iniciales

- `POST http://localhost:8080/api/usuarios/reset`

---

## 💻 Explicación del Código: Vulnerable vs Mitigado

### ❌ Código Inseguro (Concatenación Directa)

Localizado en [src/main/java/com/ejemplo/sqlinjection/service/UsuarioService.java](src/main/java/com/ejemplo/sqlinjection/service/UsuarioService.java):

```java
// INSEGURO: Permite alterar la estructura de la consulta
String sql = "SELECT * FROM usuarios WHERE username = '" + username + "' AND password = '" + password + "'";
List<Usuario> resultados = entityManager.createNativeQuery(sql, Usuario.class).getResultList();
```

### ✔️ Código Seguro (Consultas Parametrizadas)

Localizado en [src/main/java/com/ejemplo/sqlinjection/repository/UsuarioRepository.java](src/main/java/com/ejemplo/sqlinjection/repository/UsuarioRepository.java):

```java
// SEGURO: Parameter Binding con PreparedStatement
Optional<Usuario> findByUsernameAndPassword(String username, String password);

// O mediante JPQL con parámetros nombrados:
@Query("SELECT u FROM Usuario u WHERE u.username = :username AND u.password = :password")
Optional<Usuario> findByCredentialsSecure(@Param("username") String username, @Param("password") String password);
```

---

## 📖 Guía Rápida de Pruebas en el Front-End (localhost:8080)

Esta sección explica de forma sencilla cómo comprobar y contrastar el comportamiento de la aplicación en tiempo real utilizando la interfaz gráfica.

### 1. ¿Cómo se prueba en el Endpoint Vulnerable? (🔴 Panel Izquierdo)

El panel izquierdo de [Inyeccion SQL/src/main/resources/static/index.html](<Inyeccion%20SQL/src/main/resources/static/index.html>) está conectado al endpoint inseguro `/api/vulnerable/login` mapeado en [Inyeccion SQL/src/main/java/com/ejemplo/sqlinjection/controller/UsuarioController.java](<Inyeccion%20SQL/src/main/java/com/ejemplo/sqlinjection/controller/UsuarioController.java>).

- **Prueba de Bypass (Evasión de contraseña):**

  1. Haz clic en el botón (chip) **Bypass Admin: admin' --**.
  2. Esto rellenará el campo de usuario con `admin' --` (y cualquier contraseña).
  3. Haz clic en **Probar Inyección SQL**.
  4. **Resultado:** Verás que logras iniciar sesión y te devuelve la información de la cuenta del administrador, **sin conocer la contraseña**. El motor de base de datos interpretó el `--` como un comentario en MySQL, ignorando la verificación de la contraseña.
- **Prueba de Bypass Todo:**

  1. Haz clic en **Bypass Todo: ' OR '1'='1**.
  2. Presiona **Probar Inyección SQL**.
  3. **Resultado:** Te devolverá **todos** los usuarios de la base de datos de manera simultánea porque la condición `'1'='1'` siempre es verdadera.

### 2. ¿Cómo se prueba en el Endpoint Mitigado? (🟢 Panel Derecho)

Este panel está conectado al endpoint protegido `/api/mitigado/login` definido en [Inyeccion SQL/src/main/java/com/ejemplo/sqlinjection/controller/UsuarioController.java](<Inyeccion%20SQL/src/main/java/com/ejemplo/sqlinjection/controller/UsuarioController.java>).

- **Prueba de Bloqueo del Ataque:**

  1. Carga el mismo payload haciendo clic en el chip **Mismo Payload: admin' --** en el panel derecho.
  2. Haz clic en **Probar Consulta Segura**.
  3. **Resultado:** No se iniciará sesión (0 registros obtenidos). Los caracteres especiales fueron tratados como texto literal y no como código SQL debido al uso de PreparedStatements.
- **Prueba de Login Legítimo:**

  1. Haz clic en **Login Legítimo: admin / admin123**.
  2. Haz clic en **Probar Consulta Segura**.
  3. **Resultado:** Autenticación exitosa del usuario `admin` ya que los datos corresponden a sus credenciales reales de la base de datos.

### 3. Glosario de términos en la interfaz

- **Endpoint (Vulnerable / Mitigado):** Rutas del servidor que procesan la petición. El vulnerable concatena texto libre, mientras que el mitigado parametriza los valores de manera segura.
- **Payload:** Código/texto malicioso (como `'` o `--`) inyectado en un campo de texto para manipular la estructura de la consulta SQL original.
- **Consulta enviada / procesada (SQL Ejecutado):** La sentencia SQL resultante que el backend formula y envía a la base de datos.
- **Resultados obtenidos (Registros):** Número de filas de usuario devueltas por la base de datos frente a la consulta de autenticación.
- **Base de Datos MySQL (Tabla `usuarios`):** Visualización interactiva en tiempo real sobre los datos cargados en MySQL, permitiendo restaurarlos a su estado original con un solo clic.

---

## 📊 Diferencia y Casos de Prueba Detallados (Vulnerable vs Mitigado)

A continuación se asientan la diferencia teórica, el comportamiento técnico y el procedimiento paso a paso para comprobarlos en el Front-End (interfaz de usuario) tanto para los escenarios vulnerables como para sus defensas mitigadas correspondientes.

### 1. Escenario A: Bypass Booleano frente a Login (Extracción de todos los registros)

Este escenario se ejecuta en el formulario de inicio de sesión (`/api/vulnerable/login` vs `/api/mitigado/login`).

#### 🔴 Versión Vulnerable (Bypass y Extracción)

* **Diferencia conceptual:** Al concatenar `' OR '1'='1` en los parámetros de usuario y contraseña, la consulta se evalúa como verdadera para todas las filas de la tabla. Al retornar todos los registros, el backend vulnerable expone el set de datos completo al frontend.
* **Caso de Prueba en el Front-End:**
  1. En el panel izquierdo de la interfaz web (🔴), haz clic en el chip **Bypass Todo: ' OR '1'='1**.
  2. Presiona el botón del formulario **Probar Inyección SQL**.
  3. **Resultado visualizado:** Además de otorgar acceso de sesión falsa, se renderizan en pantalla **todos los registros de usuarios** existentes en la base de datos (con contraseñas llanas, saldos y correos).
  4. **Query ejecutada:**
     ```sql
     SELECT * FROM usuarios WHERE username = '' OR '1'='1' AND password = '' OR '1'='1'
     ```

#### 🟢 Versión Mitigada (Defensa Activa)

* **Diferencia conceptual:** Al usar consultas parametrizadas (`PreparedStatement`), el motor SQL trata al payload `' OR '1'='1` como un único valor literal string de búsqueda. Busca un usuario cuyo nombre de usuario registrado sea literalmente `"' OR '1'='1"`. Como no existe, el resultado lógico es vacío (`0` registros).
* **Caso de Prueba en el Front-End:**
  1. En el panel derecho de la interfaz web (🟢), escribe o copia el mismo payload `' OR '1'='1` en los campos.
  2. Presiona el botón **Probar Consulta Segura**.
  3. **Resultado visualizado:** El inicio de sesión es rechazado de forma segura, el sistema reporta **0 registros obtenidos** y no se revela ninguna información confidencial.
  4. **Query ejecutada (con parameter binding seguro):**
     ```sql
     SELECT u FROM Usuario u WHERE u.username = :username AND u.password = :password
     ```

---

### 2. Escenario B: Búsqueda Vulnerable frente a Búsqueda Mitigada

Este escenario se ejecuta en los controladores de consulta y búsqueda de registros (`/api/vulnerable/buscar` vs `/api/mitigado/buscar`).

#### 🔴 Versión Vulnerable (Modificación del Filtro / Exposición General)

* **Diferencia conceptual:** La búsqueda vulnerable concatena un string directamente en un filtro `LIKE` o `OR rol = '...'`. Un payload `' OR '1'='1` desactiva completamente los filtros de filtrado parcial de datos y obliga al motor SQL a entregar toda la información de la base de datos sin restricciones de coincidencia.
* **Caso de Prueba en el Front-End:**
  1. En la sección destinada a la búsqueda vulnerable, introduce el término `' OR '1'='1`.
  2. Presiona **Buscar**.
  3. **Resultado visualizado:** El buscador ignora el término original y, en lugar de mostrar coincidencias parciales del nombre, renderiza la lista completa de todos los datos integrados en MySQL.
  4. **Query ejecutada:**
     ```sql
     SELECT * FROM usuarios WHERE username LIKE '%' OR '1'='1%' OR rol = '' OR '1'='1'
     ```

#### 🟢 Versión Mitigada (Búsqueda Segura)

* **Diferencia conceptual:** La base de datos asocia el término introducido estrictamente a una variable de consulta parametrizada que escapa cualquier metacarácter SQL (`'`, `%`, etc.). El motor SQL buscará literalmente la subcadena `"' OR '1'='1"` impidiendo cualquier alteración sintáctica de la query.
* **Caso de Prueba en el Front-End:**
  1. En la sección dedicada a la búsqueda protegida, introduce el término `' OR '1'='1`.
  2. Presiona **Buscar**.
  3. **Resultado visualizado:** Mensaje de consulta limpia y libre de riesgos, retornando **0 coincidencias** (o solo resultados legítimos y exactos si existiera algún registro con ese texto literal).
  4. **Query ejecutada:**
     ```sql
     SELECT u FROM Usuario u WHERE u.username LIKE %:termino% OR u.email LIKE %:termino%
     ```
