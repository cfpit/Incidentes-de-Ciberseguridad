package com.ejemplo.sqlinjection.controller;

import com.ejemplo.sqlinjection.dto.SqlResultResponse;
import com.ejemplo.sqlinjection.model.Usuario;
import com.ejemplo.sqlinjection.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controlador REST que expone los endpoints tanto vulnerables como mitigados
 * para el estudio y análisis de OWASP A05:2025 (Inyección SQL).
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") // Permite peticiones desde el frontend web
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    // =========================================================================
    // ENDPOINTS VULNERABLES (DEMOSTRACIÓN DE FALLO DE SEGURIDAD)
    // =========================================================================

    /**
     * Endpoint 1 [VULNERABLE]: Login con concatenación directa de SQL.
     * Ejemplo de prueba Postman/Bruno:
     *   GET /api/vulnerable/login?username=admin' -- &password=cualquiera
     *   GET /api/vulnerable/login?username=' OR '1'='1&password=' OR '1'='1
     */
    @GetMapping("/vulnerable/login")
    public ResponseEntity<SqlResultResponse> loginVulnerable(
            @RequestParam(defaultValue = "") String username,
            @RequestParam(defaultValue = "") String password) {
        
        SqlResultResponse response = usuarioService.loginVulnerable(username, password);
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint 2 [VULNERABLE]: Búsqueda de usuario con concatenación en cláusula WHERE / LIKE.
     * Ejemplo de prueba Postman/Bruno:
     *   GET /api/vulnerable/buscar?termino=' OR '1'='1
     *   GET /api/vulnerable/buscar?termino=' UNION SELECT 100,'hacker','pass','hacker@test.com','ADMIN',99999.0 -- 
     */
    @GetMapping("/vulnerable/buscar")
    public ResponseEntity<SqlResultResponse> buscarVulnerable(
            @RequestParam(defaultValue = "") String termino) {
        
        SqlResultResponse response = usuarioService.buscarVulnerable(termino);
        return ResponseEntity.ok(response);
    }

    // =========================================================================
    // ENDPOINTS MITIGADOS (BUENAS PRÁCTICAS Y CONSULTAS PARAMETRIZADAS)
    // =========================================================================

    /**
     * Endpoint 3 [MITIGADO]: Login seguro con consultas parametrizadas (PreparedStatement).
     * El mismo payload malicioso fallará porque el motor SQL no interpretará los comandos.
     * Ejemplo de prueba Postman/Bruno:
     *   GET /api/mitigado/login?username=admin' -- &password=cualquiera
     */
    @GetMapping("/mitigado/login")
    public ResponseEntity<SqlResultResponse> loginMitigado(
            @RequestParam(defaultValue = "") String username,
            @RequestParam(defaultValue = "") String password) {
        
        SqlResultResponse response = usuarioService.loginMitigado(username, password);
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint 4 [MITIGADO]: Búsqueda segura con parameter binding.
     * Ejemplo de prueba Postman/Bruno:
     *   GET /api/mitigado/buscar?termino=' OR '1'='1
     */
    @GetMapping("/mitigado/buscar")
    public ResponseEntity<SqlResultResponse> buscarMitigado(
            @RequestParam(defaultValue = "") String termino) {
        
        SqlResultResponse response = usuarioService.buscarMitigado(termino);
        return ResponseEntity.ok(response);
    }

    // =========================================================================
    // ENDPOINTS GENERALES / DE GESTIÓN
    // =========================================================================

    /**
     * Listar todos los usuarios de la base de datos MySQL.
     */
    @GetMapping("/usuarios")
    public ResponseEntity<List<Usuario>> listarTodos() {
        return ResponseEntity.ok(usuarioService.listarTodos());
    }

    /**
     * Registrar un nuevo usuario.
     */
    @PostMapping("/usuarios")
    public ResponseEntity<Usuario> crearUsuario(@RequestBody Usuario usuario) {
        return ResponseEntity.ok(usuarioService.guardarUsuario(usuario));
    }

    /**
     * Restablecer la base de datos a los usuarios de prueba originales.
     */
    @PostMapping("/usuarios/reset")
    public ResponseEntity<Map<String, String>> resetearDatos() {
        usuarioService.reiniciarDatosPrueba();
        return ResponseEntity.ok(Map.of("mensaje", "Base de datos restaurada con los datos de prueba iniciales."));
    }
}
