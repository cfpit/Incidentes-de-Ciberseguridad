package com.ejemplo.sqlinjection.controller;

import com.ejemplo.sqlinjection.dto.SqlResultResponse;
import com.ejemplo.sqlinjection.model.Usuario;
import com.ejemplo.sqlinjection.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controlador REST que expone los endpoints tanto vulnerables como mitigados
 * para el estudio y análisis de OWASP A05:2025 (Inyección SQL).
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") // Permite peticiones desde el frontend web
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    // =========================================================================
    // ENDPOINTS VULNERABLES (DEMOSTRACIÓN DE FALLO DE SEGURIDAD)
    // =========================================================================

    /**
     * Endpoint 1 [VULNERABLE]: Login con concatenación directa de SQL.
     * Ejemplo de prueba Postman/Bruno:
     *   GET /api/vulnerable/login?username=admin' -- &password=cualquiera
     *   GET /api/vulnerable/login?username=' OR '1'='1&password=' OR '1'='1
     */
    @GetMapping("/vulnerable/login")
    public ResponseEntity<SqlResultResponse> loginVulnerable(
            @RequestParam(defaultValue = "") String username,
            @RequestParam(defaultValue = "") String password) {
        
        SqlResultResponse response = usuarioService.loginVulnerable(username, password);
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint 2 [VULNERABLE]: Búsqueda de usuario con concatenación en cláusula WHERE / LIKE.
     * Ejemplo de prueba Postman/Bruno:
     *   GET /api/vulnerable/buscar?termino=' OR '1'='1
     *   GET /api/vulnerable/buscar?termino=' UNION SELECT 100,'hacker','pass','hacker@test.com','ADMIN',99999.0 -- 
     */
    @GetMapping("/vulnerable/buscar")
    public ResponseEntity<SqlResultResponse> buscarVulnerable(
            @RequestParam(defaultValue = "") String termino) {
        
        SqlResultResponse response = usuarioService.buscarVulnerable(termino);
        return ResponseEntity.ok(response);
    }

    // =========================================================================
    // ENDPOINTS MITIGADOS (BUENAS PRÁCTICAS Y CONSULTAS PARAMETRIZADAS)
    // =========================================================================

    /**
     * Endpoint 3 [MITIGADO]: Login seguro con consultas parametrizadas (PreparedStatement).
     * El mismo payload malicioso fallará porque el motor SQL no interpretará los comandos.
     * Ejemplo de prueba Postman/Bruno:
     *   GET /api/mitigado/login?username=admin' -- &password=cualquiera
     */
    @GetMapping("/mitigado/login")
    public ResponseEntity<SqlResultResponse> loginMitigado(
            @RequestParam(defaultValue = "") String username,
            @RequestParam(defaultValue = "") String password) {
        
        SqlResultResponse response = usuarioService.loginMitigado(username, password);
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint 4 [MITIGADO]: Búsqueda segura con parameter binding.
     * Ejemplo de prueba Postman/Bruno:
     *   GET /api/mitigado/buscar?termino=' OR '1'='1
     */
    @GetMapping("/mitigado/buscar")
    public ResponseEntity<SqlResultResponse> buscarMitigado(
            @RequestParam(defaultValue = "") String termino) {
        
        SqlResultResponse response = usuarioService.buscarMitigado(termino);
        return ResponseEntity.ok(response);
    }

    // =========================================================================
    // ENDPOINTS GENERALES / DE GESTIÓN
    // =========================================================================

    /**
     * Listar todos los usuarios de la base de datos MySQL.
     */
    @GetMapping("/usuarios")
    public ResponseEntity<List<Usuario>> listarTodos() {
        return ResponseEntity.ok(usuarioService.listarTodos());
    }

    /**
     * Registrar un nuevo usuario.
     */
    @PostMapping("/usuarios")
    public ResponseEntity<Usuario> crearUsuario(@RequestBody Usuario usuario) {
        return ResponseEntity.ok(usuarioService.guardarUsuario(usuario));
    }

    /**
     * Restablecer la base de datos a los usuarios de prueba originales.
     */
    @PostMapping("/usuarios/reset")
    public ResponseEntity<Map<String, String>> resetearDatos() {
        usuarioService.reiniciarDatosPrueba();
        return ResponseEntity.ok(Map.of("mensaje", "Base de datos restaurada con los datos de prueba iniciales."));
    }

    /*
     * EXPLICACIÓN ARQUITECTÓNICA Y FUNCIONAMIENTO DE CADA ENDPOINT:
     * 
     * El flujo general de la arquitectura sigue el patrón: 
     * [Cliente/Frontend] -> [UsuarioController] -> [UsuarioService] -> [Base de Datos (H2/MySQL)]
     * Las respuestas de los endpoints que demuestran inyección SQL se encapsulan en el DTO `SqlResultResponse`.
     * Las operaciones CRUD directas utilizan la entidad de modelo `Usuario`.
     * 
     * -----------------------------------------------------------------------------------------
     * 1. GET /api/vulnerable/login
     * -----------------------------------------------------------------------------------------
     * - Método del Controller: `loginVulnerable(username, password)`
     * - Relación con la Capa de Servicio: Llama a `usuarioService.loginVulnerable(username, password)`.
     * - Relación con el DTO: Retorna un objeto `SqlResultResponse`.
     * - Cómo funciona internamente: 
     *   El controlador recopila las credenciales desde los parámetros `@RequestParam` y se las transfiere al servicio. 
     *   El servicio construye manualmente la consulta SQL de login concatenando directamente las variables en una cadena de texto.
     *   Esta consulta vulnerable se ejecuta contra la base de datos. El servicio captura tanto los registros resultantes 
     *   como la consulta de texto exacta ejecutada y el tiempo que tardó. Esta información se encapsula en el DTO 
     *   `SqlResultResponse` (que contiene campos como la query armada de forma insegura, la lista de usuarios devuelta, 
     *   un posible mensaje de error y el estado exitoso o fallido) para que el frontend pueda visualizar exactamente cómo se 
     *   manipuló la estructura de la consulta SQL.
     * 
     * -----------------------------------------------------------------------------------------
     * 2. GET /api/vulnerable/buscar
     * -----------------------------------------------------------------------------------------
     * - Método del Controller: `buscarVulnerable(termino)`
     * - Relación con la Capa de Servicio: Invoca a `usuarioService.buscarVulnerable(termino)`.
     * - Relación con el DTO: Envuelve y retorna los resultados en la estructura `SqlResultResponse`.
     * - Cómo funciona internamente: 
     *   El controlador recibe un string de búsqueda (`termino`) y lo propaga a la capa de servicio. 
     *   El servicio ejecuta una consulta SELECT vulnerable en el repositorio, interpolando el término directamente en una 
     *   sentencia SQL dinámica (usualmente concatenado dentro de cláusulas como `LIKE` o `WHERE`).
     *   Si el término de búsqueda contiene inyecciones SQL complejas (como estructuras `UNION SELECT`), el motor de la base de datos 
     *   ejecuta comandos adicionales integrados de forma maliciosa. El DTO `SqlResultResponse` actúa como contenedor para transportar 
     *   estos resultados expuestos (que pueden llegar a ser tablas enteradas del sistema), la consulta de origen armada internamente, un mensaje 
     *   de error si la sintaxis llega a fallar, y el tiempo de respuesta detallado de la infraestructura de persistencia.
     * 
     * -----------------------------------------------------------------------------------------
     * 3. GET /api/mitigado/login
     * -----------------------------------------------------------------------------------------
     * - Método del Controller: `loginMitigado(username, password)`
     * - Relación con la Capa de Servicio: Invoca a `usuarioService.loginMitigado(username, password)`.
     * - Relación con el DTO: Devuelve el resultado empaquetado en el DTO `SqlResultResponse`.
     * - Cómo funciona internamente: 
     *   El controlador recibe los parámetros del cliente de igual manera que en el modo vulnerable. Sin embargo, al enviarlos al servicio,
     *   este último implementa la mitigación utilizando consultas parametrizadas basadas en marcadores de posición (`?` o `:param`). 
     *   La plantilla de la query es precompilada por el motor de base de datos antes de enlazar los valores (binding). Por lo tanto, 
     *   los datos ingresados se interpretan puramente como valores literales de cadena. El servicio construye el DTO 
     *   `SqlResultResponse` exponiendo la consulta segura (donde se observa el uso de placeholders) y un conjunto de resultados vacío, 
     *   demostrando que el motor neutralizó el payload sin arrojar excepciones críticas ni eludir la seguridad.
     * 
     * -----------------------------------------------------------------------------------------
     * 4. GET /api/mitigado/buscar
     * -----------------------------------------------------------------------------------------
     * - Método del Controller: `buscarMitigado(termino)`
     * - Relación con la Capa de Servicio: Envía los parámetros a `usuarioService.buscarMitigado(termino)`.
     * - Relación con el DTO: Entrega un `SqlResultResponse` con la representación del esquema seguro.
     * - Cómo funciona internamente:
     *   El controlador delega al servicio un término potencialmente malicioso. El servicio utiliza la abstracción segura del framework or persistence 
     *   (como consultas JPA parametrizadas o Spring Data JPA con binding de parámetros seguro). Los metacaracteres SQL son escapados automáticamente. 
     *   La capa de servicio devuelve al controlador los datos limpios y filtrados consolidados en el DTO `SqlResultResponse`, permitiendo comprobar 
     *   que el ataque de inyección SQL fracasa y que la query parametrizada se proyecta en el DTO de forma limpia y transparente para el frontend.
     * 
     * -----------------------------------------------------------------------------------------
     * 5. GET /api/usuarios
     * -----------------------------------------------------------------------------------------
     * - Método del Controller: `listarTodos()`
     * - Relación con la Capa de Servicio: Llama directamente a `usuarioService.listarTodos()`.
     * - Relación con el Modelo/DTO: Retorna directamente una lista de entidades `List<Usuario>`.
     * - Cómo funciona internamente:
     *   Es un endpoint de inspección administrativa y visualización. El controlador llama al servicio, el cual usa un mapeador ORM o repositorio 
     *   para obtener todos los registros del modelo de entidad `Usuario` mapeados desde la tabla correspondiente. No utiliza un DTO intermedio
     *   porque el objetivo es exponer de forma cruda las filas actuales del modelo para contrastar los cambios tras un ataque.
     * 
     * -----------------------------------------------------------------------------------------
     * 6. POST /api/usuarios
     * -----------------------------------------------------------------------------------------
     * - Método del Controller: `crearUsuario(usuario)`
     * - Relación con la Capa de Servicio: Llama a `usuarioService.guardarUsuario(usuario)`.
     * - Relación con el Modelo/DTO: Recibe una entidad `@RequestBody Usuario` y retorna la misma entidad guardada e identificada.
     * - Cómo funciona internamente:
     *   El controlador deserializa el payload JSON proveniente de la solicitud HTTP directamente en una instancia de la entidad modelo `Usuario`.
     *   Esta instancia de datos se pasa al servicio, que procesa las comprobaciones de negocio necesarias y la persiste mediante el ORM seguro de 
     *   forma parametrizada. Al persistir el recurso, se genera el identificador único y se retorna el modelo actualizado directamente al cliente.
     * 
     * -----------------------------------------------------------------------------------------
     * 7. POST /api/usuarios/reset
     * -----------------------------------------------------------------------------------------
     * - Método del Controller: `resetearDatos()`
     * - Relación con la Capa de Servicio: Invoca de manera imperativa a `usuarioService.reiniciarDatosPrueba()`.
     * - Relación con el DTO: Envía un `Map<String, String>` como un mensaje estructurado de confirmación directo.
     * - Cómo funciona internamente:
     *   El controlador ejecuta esta acción sin recibir parámetros complejos. La capa de servicio borra todas las filas existentes en la base de datos 
     *   de usuarios (Truncate o Delete general) y vuelve a insertar las semillas (seeds) de prueba originales. Esto se realiza de manera segura 
     *   empleando sentencias parametrizadas nativas o consultas ORM automatizadas. Una vez completado, el controlador retorna un diccionario (Map) 
     *   con el mensaje JSON de confirmación al frontend.
     */
}
