package ar.edu.centro8.desarrollo.proyectojpa.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ar.edu.centro8.desarrollo.proyectojpa.model.Persona;
import ar.edu.centro8.desarrollo.proyectojpa.service.IPersonaService;

@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })
public class PersonaController {

    @Autowired
    private IPersonaService persoServ;

    @GetMapping("/personas/traer")
    public List<Persona> getPersonas() {
        return persoServ.getPersonas();
    }

    @PostMapping("/personas/crear")
    public String savePersona(@RequestBody Persona perso) {
        persoServ.savePersona(perso);

        return "La persona fue creada correctamente";
    }

    @DeleteMapping("/personas/borrar/{id}")
    public String deletePersona(@PathVariable Long id) {
        persoServ.deletePersona(id);
        return "La persona fue eliminada correctamente";
    }


    @PutMapping("/personas/editar/{id_original}")
    public Persona editPersona(@PathVariable Long id_original,
            @RequestBody Persona personaEditada) {

        // Usamos el id_original de la ruta para buscar y actualizar
        persoServ.editPersona(id_original,
                id_original,
                personaEditada.getNombre(),
                personaEditada.getEdad());

        return persoServ.findPersona(id_original);
    }
}

/*
	API Testing
	
	1)@GetMapping("/personas/traer
	http://localhost:8080/personas/traer
	
	
	2)@PostMapping("/personas/crear")
	http://localhost:8080/personas/crear
	
	Body (raw > JSON):
	{
		"nombre":"Juan Perez",
		"edad":45
	}
	
	
	3)@DeleteMapping("/personas/borrar/{id}")
	http://localhost:8080/personas/borrar/1
	
	
	
	4)PutMapping("/personas/editar/{id_original}")
	URL en Postman: http://localhost:8080/personas/editar/1

	Body (raw > JSON):
	{
	  "nombre": "Juancito Perez",
	  "edad": 46
	}

*/
